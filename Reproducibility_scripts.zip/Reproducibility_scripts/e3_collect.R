# collect per-fold E3 results into results/e3_final.rds
if (file.exists("results/e3_folds.rds")) {
  r <- readRDS("results/e3_folds.rds")
  x <- do.call(rbind, r); rownames(x) <- NULL
  old <- x$scheme == "CV1" & x$model == "GBLUP: E + G" & x$time > 40
  x$time[old] <- x$time[old] / 5          # previous run stored the total of 5 folds
  saveRDS(x, "results/e3_final.rds")
}
