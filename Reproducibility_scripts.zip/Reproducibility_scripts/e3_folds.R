suppressMessages(library(TwoStageGP, lib.loc = "/home/claude/rlib2"))
data(wheat599)
X <- wheat599$X; Y <- wheat599$Y
G <- kernel_linear(X); E <- kernel_identity(colnames(Y))
d <- data.frame(gen = rep(rownames(Y), 4), env = rep(colnames(Y), each = 599), y = as.vector(Y))
models <- list(
  "GBLUP: E + G"      = list(G = list(id = "gen", K = G)),
  "GBLUP: E + G + GE" = list(G = list(id = "gen", K = G), GE = list(id = c("gen", "env"), K = list(G, E))))
fc <- "results/e3_folds.rds"
res <- if (file.exists(fc)) readRDS(fc) else list()
# import the complete CV1 E+G run done before
old <- readRDS("results/e3_multi_env_cv.rds")
for (f in unique(old$fold)) { k <- paste("CV1", "GBLUP: E + G", f); if (is.null(res[[k]])) res[[k]] <- old[old$fold == f, ] }
saveRDS(res, fc)
plan <- list(c("CV2", "GBLUP: E + G"), c("CV2", "GBLUP: E + G + GE"), c("CV1", "GBLUP: E + G + GE"))
for (pl in plan) {
  part <- cv_partition(d, "gen", "env", pl[1], folds = 5, seed = 2024)
  for (i in seq_along(part$folds)) {
    k <- paste(pl[1], pl[2], part$folds[[i]]$id)
    if (!is.null(res[[k]])) next
    p1 <- part; p1$folds <- part$folds[i]
    cv <- gp_cv(d, "y", "gen", "env", ETA = models[[pl[2]]], partition = p1, approach = "two-stage", verbose = FALSE)
    res[[k]] <- data.frame(scheme = pl[1], model = pl[2], cv$metrics, time = cv$fold_times)
    saveRDS(res, fc); cat(k, round(cv$fold_times, 1), round(mean(cv$metrics$cor), 3), "\n")
  }
}
cat("E3 folds finished\n")
