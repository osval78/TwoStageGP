source("analysis/e3_collect.R")
library(jsonlite)
vals <- fromJSON("article/vals.json", simplifyVector = FALSE)
t <- readRDS("results/tables.rds")
f3 <- function(x) formatC(x, format = "f", digits = 3)
f4 <- function(x) formatC(x, format = "f", digits = 4)
v <- t$val
vals$tab_val <- lapply(seq_len(nrow(v)), function(i) c(v$env[i], sprintf("%.5f", v$s2g_tsgp[i]), sprintf("%.5f", v$s2g_rr[i]),
  sprintf("%.5f", v$s2e_tsgp[i]), sprintf("%.5f", v$s2e_rr[i]), sprintf("%.1e", v$maxdiff[i]), sprintf("%.0f", v$maxdiff_RR[i]), sprintf("%.1f", v$t_G[i])))
F <- t$e4_full; S <- t$e4_full_stats
g <- function(m, comp, col) F[F$model == m & F$component == comp, col]
row <- function(lbl, comp) c(lbl, f3(g("GBLUP", comp, "one")), f3(g("GBLUP", comp, "two")), f3(g("GBLUP", comp, "two_w")),
                                  f3(g("RKHS", comp, "one")), f3(g("RKHS", comp, "two")), f3(g("RKHS", comp, "two_w")))
sg <- S[S$model == "GBLUP", ]; sk <- S[S$model == "RKHS", ]
vals$tab_full <- list(row("σ²g", "G"), row("σ²ge", "GE"), row("Residual (σ²e or σ²ε)", "Residual"),
  c("Correlation with one-stage predictions", "1", sprintf("%.5f", sg$cor_12), sprintf("%.5f", sg$cor_12w), "1", sprintf("%.5f", sk$cor_12), sprintf("%.5f", sk$cor_12w)),
  c("Accuracy (true genetic value)", f4(sg$acc_one), f4(sg$acc_two), f4(sg$acc_twow), f4(sk$acc_one), f4(sk$acc_two), f4(sk$acc_twow)),
  c("Computing time (s)", sprintf("%.1f", sg$t_one), sprintf("%.1f", sg$t_two), "—", sprintf("%.1f", sk$t_one), sprintf("%.1f", sk$t_two), "—"))
vals$full <- list(cor_g = sprintf("%.5f", sg$cor_12), md_g = sprintf("%.3f", sg$maxdiff), cor_k = sprintf("%.5f", sk$cor_12), cor_gw = sprintf("%.5f", sg$cor_12w))
C <- t$e4_cv_summary; T <- t$e4_cv_time
ord <- list(c("CV1","GBLUP"), c("CV2","GBLUP"), c("CV0","GBLUP"), c("CV1","RKHS"), c("CV2","RKHS"))
vals$tab_cv <- lapply(ord, function(o) {
  a <- C[C$scheme == o[1] & C$model == o[2], ]; tt <- T[T$scheme == o[1] & T$model == o[2], ]
  o1 <- a[a$approach == "one-stage", ]; o2 <- a[a$approach == "two-stage", ]
  t1 <- tt$total[tt$approach == "one-stage"]; t2 <- tt$total[tt$approach == "two-stage"]
  c(o[1], o[2], sprintf("%.3f ± %.3f", o1$cor, o1$se), sprintf("%.3f ± %.3f", o2$cor, o2$se), f3(o1$cor_truth), f3(o2$cor_truth),
    sprintf("%.1f", t1), sprintf("%.1f", t2), sprintf("%.1f", t1 / t2)) })
## E2 paragraphs
if (file.exists("results/e2_single_env_cv.rds")) {
  e2 <- readRDS("results/e2_single_env_cv.rds")
  a <- aggregate(cor ~ model + env, e2, mean); am <- aggregate(cor ~ model, e2, mean)
  tm <- aggregate(time ~ model, e2, mean)
  gm <- function(m, e) a$cor[a$model == m & a$env == e]
  envs <- paste0("E", 1:4)
  best <- sapply(envs, function(e) { x <- a[a$env == e, ]; x$model[which.max(x$cor)] })
  lab <- c(GBLUP = "GBLUP", RR = "RR-BLUP", RKHS = "RKHS", GA = "G + A")
  p1 <- sprintf("Figure 5 shows the predictive ability of the single-environment models under random 5-fold cross-validation (equivalent to CV1 within environment). GBLUP and RR-BLUP gave identical results in every fold, with mean predictive abilities of %s, %s, %s and %s in E1 to E4, which confirms in a cross-validation setting that both are the same model. The RKHS model with a Gaussian kernel reached %s, %s, %s and %s, and the model that combined markers and pedigree (G + A) reached %s, %s, %s and %s. Averaged over environments, the predictive abilities were %s for GBLUP and RR-BLUP, %s for RKHS and %s for G + A, and the best model was %s in E1, %s in E2, %s in E3 and %s in E4.",
    f3(gm("GBLUP","E1")), f3(gm("GBLUP","E2")), f3(gm("GBLUP","E3")), f3(gm("GBLUP","E4")),
    f3(gm("RKHS","E1")), f3(gm("RKHS","E2")), f3(gm("RKHS","E3")), f3(gm("RKHS","E4")),
    f3(gm("GA","E1")), f3(gm("GA","E2")), f3(gm("GA","E3")), f3(gm("GA","E4")),
    f3(am$cor[am$model=="GBLUP"]), f3(am$cor[am$model=="RKHS"]), f3(am$cor[am$model=="GA"]),
    lab[best[1]], lab[best[2]], lab[best[3]], lab[best[4]])
  p2 <- sprintf("These values are of the same order as those reported for these data with Bayesian and kernel methods (Crossa et al., 2010; Pérez & de los Campos, 2014). The total time of a complete 5-fold cross-validation in one environment was %.0f s for GBLUP, %.0f s for RR-BLUP, %.0f s for RKHS and %.0f s for G + A, so adding a second dense kernel (pedigree) multiplied the cost by about %.0f, whereas the gain in predictive ability with respect to GBLUP ranged from %.3f to %.3f.",
    tm$time[tm$model=="GBLUP"], tm$time[tm$model=="RR"], tm$time[tm$model=="RKHS"], tm$time[tm$model=="GA"],
    tm$time[tm$model=="GA"] / tm$time[tm$model=="GBLUP"],
    min(sapply(envs, function(e) gm("GA", e) - gm("GBLUP", e))), max(sapply(envs, function(e) gm("GA", e) - gm("GBLUP", e))))
  vals$e2_paras <- list(list(t = "p", text = p1), list(t = "p", text = p2))
} else vals$e2_paras <- list()
## E3 paragraphs
if (file.exists("results/e3_final.rds")) {
  e3 <- readRDS("results/e3_final.rds"); full3 <- readRDS("results/e3_full.rds")
  a <- aggregate(cor ~ scheme + model + env, e3, mean); am <- aggregate(cor ~ scheme + model, e3, mean)
  tm <- aggregate(time ~ scheme + model, e3, mean)
  gm <- function(s, m) am$cor[am$scheme == s & am$model == m]
  ge <- function(s, m, e) a$cor[a$scheme == s & a$model == m & a$env == e]
  M <- names(full3)
  vc <- function(m, c) { x <- full3[[m]]$varcomp; x$variance[x$component == c] }
  have <- function(s, m) any(am$scheme == s & am$model == m)
  txt <- sprintf("When the four environments were analyzed jointly, the variance of the G×E term was larger than that of the genomic main effect (σ̂²_{ge} = %s versus σ̂²_{g} = %s in the GBLUP E + G + G×E model), which is consistent with the low and even negative correlations between E1 and the other environments. The E + G + G×E models also had a much better fit than the E + G model (AIC of %s versus %s). A full multi-environment fit with 2,396 records and 2,995 random-effect levels took %.0f s for E + G and %.0f s for E + G + G×E with GBLUP.",
    f3(vc(M[2], "GE")), f3(vc(M[2], "G")), sprintf("%.1f", full3[[M[2]]]$AIC), sprintf("%.1f", full3[[M[1]]]$AIC), full3[[M[1]]]$time, full3[[M[2]]]$time)
  if (length(M) >= 3) txt <- paste(txt, sprintf("Replacing the linear kernel by the Gaussian kernel in both genomic terms (RKHS E + G + G×E) gave σ̂²_{g} = %s, σ̂²_{ge} = %s and an AIC of %s, %s than that of the GBLUP version, and the fit took %.0f s.",
    f3(vc(M[3], "G")), f3(vc(M[3], "GE")), sprintf("%.1f", full3[[M[3]]]$AIC),
    if (full3[[M[3]]]$AIC < full3[[M[2]]]$AIC) "lower" else "higher", full3[[M[3]]]$time))
  parts <- list(list(t = "p", text = txt))
  sch_txt <- c()
  for (s in c("CV1", "CV2")) {
    ok <- sapply(M, function(m) have(s, m))
    if (!any(ok)) next
    mm <- M[ok]
    sch_txt <- c(sch_txt, sprintf("Under %s, the mean predictive ability across folds and environments was %s.", s,
      paste(sprintf("%s for %s", f3(sapply(mm, function(m) gm(s, m))), mm), collapse = " and ")))
  }
  if (have("CV2", M[1]) && have("CV2", M[2]))
    sch_txt <- c(sch_txt, sprintf("Modelling G×E increased the CV2 predictive ability from %s to %s on average; the changes were %s, %s and %s in E2, E3 and E4, which are positively correlated among themselves, whereas in E1, whose correlations with the other environments are negative, the predictive ability changed from %s to %s, because the E + G model forces a common genomic effect across environments that is not valid for E1.",
      f3(gm("CV2", M[1])), f3(gm("CV2", M[2])),
      sprintf("%+.3f", ge("CV2", M[2], "E2") - ge("CV2", M[1], "E2")), sprintf("%+.3f", ge("CV2", M[2], "E3") - ge("CV2", M[1], "E3")),
      sprintf("%+.3f", ge("CV2", M[2], "E4") - ge("CV2", M[1], "E4")), f3(ge("CV2", M[1], "E1")), f3(ge("CV2", M[2], "E1"))))
  if (have("CV1", M[1]) && have("CV1", M[2]))
    sch_txt <- c(sch_txt, sprintf("In CV1 the lines to be predicted have no records in any environment, so the G×E term can contribute only through the genomic relationships, and the predictive ability changed from %s (E + G) to %s (E + G + G×E), again with the largest gain in E1. Under the G×E model, CV2 was only slightly better than CV1 (%s versus %s), because the low correlations among environments make the records of a line in other environments little informative. The mean time per fold was %s.",
      f3(gm("CV1", M[1])), f3(gm("CV1", M[2])), f3(gm("CV2", M[2])), f3(gm("CV1", M[2])), paste(sprintf("%.0f s for %s under %s", tm$time, tm$model, tm$scheme), collapse = ", ")))
  parts[[2]] <- list(t = "p", text = paste(sch_txt, collapse = " "))
  parts <- lapply(parts, function(p) { p$text <- gsub("GBLUP: E + G + GE", "the E + G + G×E model", p$text, fixed = TRUE); p$text <- gsub("GBLUP: E + G", "the E + G model", p$text, fixed = TRUE); p })
  vals$e3_paras <- parts
} else vals$e3_paras <- list()
writeLines(toJSON(vals, auto_unbox = TRUE, pretty = TRUE, digits = NA), "article/vals.json")
cat("ok\n")
