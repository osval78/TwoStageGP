suppressMessages(library(TwoStageGP))
data(wheat599)
res <- list()
for (nr in c(2, 3)) for (ng in c(100, 200, 300, 400)) {
  X <- wheat599$X[1:ng, ]
  sim <- simulate_met(X, n_env = 4, n_rep = nr, seed = ng + nr)
  G <- kernel_linear(X); E <- kernel_identity(paste0("E", 1:4))
  ETA <- prepare_ETA(list(G = list(id = "gen", K = G), GE = list(id = c("gen", "env"), K = list(G, E))), sim$data)
  one <- one_stage(sim$data, "yield", "gen", "env", "rep", ETA = ETA)
  two <- two_stage(sim$data, "yield", "gen", "env", "rep", ETA = ETA, weighting = "none")
  cs <- compare_stages(one, two)
  res[[paste(ng, nr)]] <- data.frame(n_gen = ng, n_rep = nr, n_plots = nrow(sim$data),
     t_one = one$time_total, t_two = two$time_total, t_s1 = two$time_stage1,
     cor = cs$cor, maxdiff = cs$max_abs_diff)
  print(res[[paste(ng, nr)]])
  saveRDS(do.call(rbind, res), "results/e5_scaling.rds")
}
cat("E5 finished\n")
