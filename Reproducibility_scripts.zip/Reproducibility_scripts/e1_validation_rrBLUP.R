suppressMessages({library(TwoStageGP); library(rrBLUP)})
data(wheat599)
X <- wheat599$X; Y <- wheat599$Y; A <- wheat599$A
G <- kernel_linear(X); KG <- kernel_gaussian(X, h = 1)
KG3 <- kernel_gaussian(X, h = c(0.25, 1, 4))
envs <- colnames(Y)
## E1: validation against rrBLUP and RR equivalence
val <- list()
for (e in envs) {
  d <- data.frame(gen = rownames(Y), env = e, y = Y[, e])
  fg <- gp_fit(y ~ 1, d, list(G = list(id = "gen", K = G)))
  fr <- gp_fit(y ~ 1, d, list(M = list(id = "gen", X = X, model = "RR")))
  ms <- mixed.solve(d$y, K = G)
  val[[e]] <- list(env = e, tsgp_G = fg$random$G, tsgp_RR = fr$random$M, rrblup = as.vector(ms$u),
                   vc_tsgp = fg$varcomp$variance, vc_rrblup = c(ms$Vu, ms$Ve),
                   beta = fr$marker_effects$M, time_G = fg$time, time_RR = fr$time,
                   logLik = fg$logLik)
  cat(e, "done\n")
}
saveRDS(val, "results/e1_validation.rds")
## E2: single-environment CV (random 5-fold) GBLUP, RR, RKHS, multi-kernel RKHS, G+A
models <- list(GBLUP = list(G = list(id = "gen", K = G, model = "GBLUP")),
               RR    = list(M = list(id = "gen", X = X, model = "RR")),
               RKHS  = list(K = list(id = "gen", K = KG, model = "RKHS")),
               RKHS_KA = list(K1 = list(id = "gen", K = KG3[[1]], model = "RKHS"),
                              K2 = list(id = "gen", K = KG3[[2]], model = "RKHS"),
                              K3 = list(id = "gen", K = KG3[[3]], model = "RKHS")),
               GA    = list(G = list(id = "gen", K = G), A = list(id = "gen", K = A, model = "K")))
res <- list()
for (e in envs) {
  d <- data.frame(gen = rownames(Y), env = e, y = Y[, e])
  part <- cv_partition(d, "gen", "env", "random", folds = 5, seed = 2024)
  for (m in names(models)) {
    cv <- gp_cv(d, "y", "gen", "env", ETA = models[[m]], partition = part,
                approach = "two-stage", fixed = y ~ 1, verbose = FALSE)
    res[[paste(e, m)]] <- data.frame(env = e, model = m, cv$metrics, time = cv$time["total"])
    cat(e, m, round(mean(cv$metrics$cor), 3), round(cv$time["total"], 1), "\n")
  }
}
saveRDS(do.call(rbind, res), "results/e2_single_env_cv.rds")
