import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams["font.family"]="DejaVu Sans"
fig, ax = plt.subplots(figsize=(11, 7.2)); ax.set_xlim(0,110); ax.set_ylim(0,72); ax.axis("off")
def box(x,y,w,h,title,body,fc,ec):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.4,rounding_size=1.5",fc=fc,ec=ec,lw=1.4))
    ax.text(x+w/2,y+h-2.6,title,ha="center",va="top",fontsize=10.5,weight="bold",color="#1b1b1b")
    ax.text(x+w/2,y+h-6.6,body,ha="center",va="top",fontsize=8.3,color="#222",linespacing=1.35,family="DejaVu Sans Mono")
def arr(x1,y1,x2,y2,c="#444",ls="-"):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle="-|>",mutation_scale=14,color=c,lw=1.4,linestyle=ls))
# inputs
box(1,52,30,18,"Inputs","markers X (lines x SNPs)\nenvironmental covariates W\npedigree A\nplot records y_ijk\n(gen, env, rep, block)","#eef3fb","#3b6db3")
box(37,52,34,18,"Kernels","kernel_linear(X)    GBLUP\nkernel_gaussian(X,h) RKHS\nkernel_env(W)        Omega\nkernel_identity()    I\nX directly           RR","#eef3fb","#3b6db3")
box(77,52,32,18,"Linear predictor (ETA)","list(G =list(id=\"gen\",K=G),\n     GE=list(id=c(\"gen\",\"env\"),\n             K=list(G,I)))\nprepare_ETA(): K = L L'","#eef3fb","#3b6db3")
arr(31.8,61,36.2,61); arr(71.8,61,76.2,61)
# two branches
box(1,30,47,16,"One-stage  [one_stage()]","y_ijk = mu + E_j + R(E)_jk\n      + g_i + ge_ij + e_ijk\nall plots, design + genomic terms\nfitted jointly by REML","#fdf1e7","#c2611f")
box(56,30,24,16,"Stage 1  [stage1()]","per environment:\ny ~ 0 + gen + rep\n(+ (1|rep:block))\nBLUEs, SE, weights","#e9f6ee","#2e8b57")
box(84,30,25,16,"Stage 2  [two_stage()]","BLUE_ij = mu + E_j\n  + g_i + ge_ij + e_ij\nweights w_ij ~ 1/SE^2","#e9f6ee","#2e8b57")
arr(88,51.2,30,46.8,"#c2611f"); arr(90,51.2,95,46.8,"#2e8b57")
arr(80.8,38,83.2,38,"#2e8b57")
ax.text(96.5,48.6,"two-stage",fontsize=9,color="#2e8b57",style="italic")
ax.text(52,49.5,"one-stage",fontsize=9,color="#c2611f",style="italic")
# lme4 engine
box(20,6,70,14,"lme4 engine  [gp_fit()]","lFormula -> replace Z_k by Z_k L_k -> mkLmerDevfun -> optimizeLmer -> mkMerMod\nu_k = L_k z_k ,  z_k ~ N(0, s2_k I)   =>   u_k ~ N(0, s2_k K_k)\npredictions for all kernel levels (lines without phenotypes included)","#f4f0fa","#6a4c9c")
arr(24,29.2,40,20.8,"#6a4c9c"); arr(96,29.2,72,20.8,"#6a4c9c")
# outputs
ax.text(55,2.2,"Outputs: variance components, fixed effects, GEBVs (g, ge), marker effects (RR), predict(), cv_partition() + gp_cv(): CV1, CV2, CV0, CV00",ha="center",fontsize=8.8,color="#333")
plt.savefig("figs/Figure1_workflow.png",dpi=600,bbox_inches="tight")
plt.savefig("figs/Figure1_workflow.tiff",dpi=600,bbox_inches="tight",pil_kwargs={"compression":"tiff_lzw"})
