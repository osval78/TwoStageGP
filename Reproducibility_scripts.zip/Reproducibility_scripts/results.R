source("analysis/e3_collect.R")
suppressMessages(library(TwoStageGP, lib.loc = "/home/claude/rlib2"))
data(wheat599)
dir.create("figs", showWarnings = FALSE)
col1 <- "#c2611f"; col2 <- "#2e8b57"; cols4 <- c("#1b9e77", "#d95f02", "#7570b3", "#e7298a")
ex <- function(f) file.exists(f)
vals <- list(version = as.character(packageVersion("TwoStageGP", lib.loc = "/home/claude/rlib2")))
tabs <- list()
fmt <- function(x, d = 3) formatC(x, format = "f", digits = d)
png2 <- function(f, w, h) png(f, width = w, height = h, units = "in", res = 600, type = "cairo")

## ---------- E1 validation ----------
v <- readRDS("results/e1_validation.rds")
md <- max(sapply(v, function(x) max(abs(x$tsgp_G - x$rrblup))))
vals$val_maxdiff <- sprintf("%.1e", md)
tabs$val <- do.call(rbind, lapply(v, function(x) data.frame(env = x$env,
  s2g_tsgp = x$vc_tsgp[1], s2g_rr = x$vc_rrblup[1], s2e_tsgp = x$vc_tsgp[2], s2e_rr = x$vc_rrblup[2],
  maxdiff = max(abs(x$tsgp_G - x$rrblup)), maxdiff_RR = max(abs(x$tsgp_G - x$tsgp_RR)),
  t_G = x$time_G, t_RR = x$time_RR)))
png2("figs/Figure4_validation.png", 10, 3.6)
par(mfrow = c(1, 3), mar = c(4.3, 4.5, 3, 1), las = 1)
plot(NA, xlim = range(sapply(v, `[[`, "rrblup")), ylim = range(sapply(v, `[[`, "tsgp_G")),
     xlab = "GEBV, rrBLUP::mixed.solve", ylab = "GEBV, TwoStageGP (GBLUP)", main = "(a) TwoStageGP vs rrBLUP")
for (i in seq_along(v)) points(v[[i]]$rrblup, v[[i]]$tsgp_G, pch = 16, cex = 0.6, col = adjustcolor(cols4[i], 0.6))
abline(0, 1, lty = 2); legend("topleft", names(v), pch = 16, col = cols4, bty = "n", cex = 0.9)
plot(NA, xlim = range(sapply(v, `[[`, "tsgp_RR")), ylim = range(sapply(v, `[[`, "tsgp_G")),
     xlab = "GEBV, ridge regression (RR)", ylab = "GEBV, GBLUP", main = "(b) GBLUP vs RR-BLUP")
for (i in seq_along(v)) points(v[[i]]$tsgp_RR, v[[i]]$tsgp_G, pch = 16, cex = 0.6, col = adjustcolor(cols4[i], 0.6))
abline(0, 1, lty = 2)
b <- v[[1]]$beta
plot(seq_along(b), b, type = "h", col = "grey40", xlab = "Marker index", ylab = "Estimated marker effect",
     main = "(c) RR marker effects, E1")
top <- order(-abs(b))[1:10]; points(top, b[top], pch = 16, col = "#d7191c", cex = 0.8)
dev.off()

## ---------- E2 single-env CV ----------
if (ex("results/e2_single_env_cv.rds")) {
  e2 <- readRDS("results/e2_single_env_cv.rds")
  agg <- aggregate(cor ~ model + env, e2, function(x) c(m = mean(x), se = sd(x) / sqrt(length(x))))
  agg <- do.call(data.frame, agg)
  tm <- aggregate(time ~ model + env, e2, mean)
  tabs$e2 <- merge(agg, tm)
  mods <- c("GBLUP", "RR", "RKHS", "GA")
  labs <- c("GBLUP", "RR-BLUP", "RKHS", "GBLUP + A")
  M <- sapply(mods, function(m) sapply(paste0("E", 1:4), function(e) agg$cor.m[agg$model == m & agg$env == e]))
  S <- sapply(mods, function(m) sapply(paste0("E", 1:4), function(e) agg$cor.se[agg$model == m & agg$env == e]))
  png2("figs/Figure5_wheat_single_env.png", 8, 4.4)
  par(mar = c(4, 4.5, 1, 1), las = 1)
  bp <- barplot(t(M), beside = TRUE, col = c("#4575b4", "#91bfdb", "#fc8d59", "#999999"),
                ylim = c(0, max(M + S) * 1.18), ylab = "Predictive ability (Pearson r)", xlab = "Environment", border = NA)
  arrows(bp, t(M - S), bp, t(M + S), angle = 90, code = 3, length = 0.025, lwd = 0.8)
  legend("topleft", labs, fill = c("#4575b4", "#91bfdb", "#fc8d59", "#999999"), bty = "n", ncol = 4, cex = 0.85, border = NA)
  dev.off()
  vals$e2_M <- round(M, 3); vals$e2_S <- round(S, 3)
}

## ---------- E3 multi-env wheat ----------
if (ex("results/e3_final.rds")) {
  e3 <- readRDS("results/e3_final.rds")
  full3 <- readRDS("results/e3_full.rds"); vals$e3_full <- full3
  agg <- do.call(data.frame, aggregate(cor ~ scheme + model + env, e3, function(x) c(m = mean(x), se = sd(x) / sqrt(length(x)))))
  tabs$e3 <- agg
  tabs$e3_time <- aggregate(time ~ scheme + model, e3, mean)
  mods <- unique(e3$model)
  png2("figs/Figure6_wheat_multi_env.png", 10, 4.2)
  par(mfrow = c(1, 2), mar = c(4, 4.5, 3, 1), las = 1)
  for (s in c("CV1", "CV2")) {
    a <- agg[agg$scheme == s, ]
    M <- sapply(mods, function(m) sapply(paste0("E", 1:4), function(e) a$cor.m[a$model == m & a$env == e]))
    S <- sapply(mods, function(m) sapply(paste0("E", 1:4), function(e) a$cor.se[a$model == m & a$env == e]))
    if (is.list(M)) next
    bp <- barplot(t(M), beside = TRUE, col = c("#9ecae1", "#3182bd", "#e6550d")[seq_along(mods)], border = NA,
                  ylim = c(min(0, min(M - S)), 0.85), ylab = "Predictive ability (Pearson r)", xlab = "Environment",
                  main = paste0("(", letters[match(s, c("CV1", "CV2"))], ") ", s))
    arrows(bp, t(M - S), bp, t(M + S), angle = 90, code = 3, length = 0.025, lwd = 0.8)
    if (s == "CV1") legend("topleft", mods, fill = c("#9ecae1", "#3182bd", "#e6550d")[seq_along(mods)], bty = "n", cex = 0.85, border = NA)
  }
  dev.off()
}

## ---------- E4 one vs two stage: full fits ----------
f4 <- readRDS("results/e4_full.rds")
sim <- readRDS("results/sim_data.rds")
png2("figs/Figure7_one_vs_two_full.png", 10, 3.7)
par(mfrow = c(1, 3), mar = c(4.3, 4.5, 3, 1), las = 1)
for (i in seq_along(f4)) {
  p <- f4[[i]]$cmp$predictions
  ee <- as.integer(factor(p$env))
  plot(p$one_stage, p$two_stage, pch = 16, cex = 0.45, col = adjustcolor(cols4[ee], 0.5),
       xlab = "Predicted g + ge, one-stage", ylab = "Predicted g + ge, two-stage",
       main = sprintf("(%s) %s: r = %.5f", letters[i], names(f4)[i], f4[[i]]$cmp$cor))
  abline(0, 1, lty = 2)
  if (i == 1) legend("topleft", paste0("E", 1:4), pch = 16, col = cols4, bty = "n", cex = 0.85)
}
vc <- sapply(f4, function(x) {
  a <- x$cmp$varcomp; r <- sim$params$n_rep
  c(a$variance_one_stage[a$component == "G"], a$variance_two_stage[a$component == "G"],
    a$variance_one_stage[a$component == "GE"], a$variance_two_stage[a$component == "GE"],
    a$variance_one_stage[a$component == "Residual"] / r, a$variance_two_stage[a$component == "Residual"])
})
Mv <- rbind(vc[c(1, 3, 5), "GBLUP"], vc[c(2, 4, 6), "GBLUP"], vc[c(1, 3, 5), "RKHS"], vc[c(2, 4, 6), "RKHS"])
bp <- barplot(Mv, beside = TRUE, col = c(col1, col2, adjustcolor(col1, 0.45), adjustcolor(col2, 0.45)), border = NA,
              names.arg = c(expression(sigma[g]^2), expression(sigma[ge]^2), expression(sigma[e]^2 / r ~ "vs" ~ sigma[epsilon]^2)),
              ylab = "Variance estimate", main = "(c) Variance components", ylim = c(0, max(Mv) * 1.25))
abline(h = c(sim$params$var_g, sim$params$var_ge, sim$params$var_e / sim$params$n_rep), lty = 3, col = "grey40")
legend("topleft", c("GBLUP one-stage", "GBLUP two-stage", "RKHS one-stage", "RKHS two-stage"),
       fill = c(col1, col2, adjustcolor(col1, 0.45), adjustcolor(col2, 0.45)), bty = "n", cex = 0.8, border = NA)
dev.off()
tabs$e4_full <- do.call(rbind, lapply(names(f4), function(m) { x <- f4[[m]]; a <- x$cmp$varcomp; aw <- x$cmpw$varcomp
  data.frame(model = m, component = a$component, one = a$variance_one_stage, two = a$variance_two_stage, two_w = aw$variance_two_stage) }))
tabs$e4_full_stats <- do.call(rbind, lapply(names(f4), function(m) { x <- f4[[m]]
  data.frame(model = m, cor_12 = x$cmp$cor, maxdiff = x$cmp$max_abs_diff, cor_12w = x$cmpw$cor,
    acc_one = cor(x$cmp$predictions$one_stage, x$truth), acc_two = cor(x$cmp$predictions$two_stage, x$truth),
    acc_twow = cor(x$cmpw$predictions$two_stage, x$truth),
    t_one = x$time["one"], t_two = x$time["two"], t_s1 = x$time["s1"], t_s2 = x$time["s2"]) }))

## ---------- E4 CV ----------
cv <- readRDS("results/e4_cv.rds")
Mt <- do.call(rbind, lapply(cv, `[[`, "metrics"))
Tt <- do.call(rbind, lapply(names(cv), function(n) { x <- cv[[n]]; data.frame(scheme = x$metrics$scheme[1], model = x$metrics$model[1],
  approach = x$metrics$approach[1], stage1 = x$time["stage1"], prepare = x$time["prepare"], fitting = x$time["fitting"], total = x$time["total"],
  mean_fold = mean(x$fold_times)) }))
tabs$e4_cv_time <- Tt
key <- paste(Mt$scheme, Mt$model, Mt$fold, Mt$env)
one <- Mt[Mt$approach == "one-stage", ]; two <- Mt[Mt$approach == "two-stage", ]
pr <- merge(one, two, by = c("scheme", "model", "fold", "env"), suffixes = c("_one", "_two"))
tabs$e4_cv_paired <- pr
S4 <- do.call(rbind, lapply(split(Mt, list(Mt$scheme, Mt$model, Mt$approach), drop = TRUE), function(d)
  data.frame(scheme = d$scheme[1], model = d$model[1], approach = d$approach[1], cor = mean(d$cor), se = sd(d$cor) / sqrt(nrow(d)),
             cor_truth = mean(d$cor_truth), MSE = mean(d$MSE, na.rm = TRUE))))
tabs$e4_cv_summary <- S4
png2("figs/Figure8_cv_one_vs_two.png", 10, 4.3)
par(mfrow = c(1, 2), mar = c(4.3, 4.5, 3, 1), las = 1)
grp <- paste(pr$scheme, pr$model)
ug <- unique(grp); gcol <- setNames(c("#1b9e77", "#d95f02", "#7570b3", "#e7298a", "#66a61e")[seq_along(ug)], ug)
plot(pr$cor_one, pr$cor_two, pch = 16, col = adjustcolor(gcol[grp], 0.75), xlab = "Predictive ability, one-stage",
     ylab = "Predictive ability, two-stage", main = sprintf("(a) Fold x environment, r = %.4f", cor(pr$cor_one, pr$cor_two)))
abline(0, 1, lty = 2); legend("topleft", ug, pch = 16, col = gcol, bty = "n", cex = 0.8)
lab <- unique(paste(S4$scheme, S4$model))
lab <- lab[order(match(sub(" .*", "", lab), c("CV1", "CV2", "CV0")), lab)]
m1 <- sapply(lab, function(l) S4$cor[paste(S4$scheme, S4$model) == l & S4$approach == "one-stage"])
m2 <- sapply(lab, function(l) S4$cor[paste(S4$scheme, S4$model) == l & S4$approach == "two-stage"])
s1 <- sapply(lab, function(l) S4$se[paste(S4$scheme, S4$model) == l & S4$approach == "one-stage"])
s2 <- sapply(lab, function(l) S4$se[paste(S4$scheme, S4$model) == l & S4$approach == "two-stage"])
t1 <- sapply(lab, function(l) S4$cor_truth[paste(S4$scheme, S4$model) == l & S4$approach == "one-stage"])
t2 <- sapply(lab, function(l) S4$cor_truth[paste(S4$scheme, S4$model) == l & S4$approach == "two-stage"])
bp <- barplot(rbind(m1, m2), beside = TRUE, col = c(col1, col2), border = NA, ylim = c(0, 1.32), names.arg = sub(" ", "\n", lab),
              ylab = "Mean predictive ability", main = "(b) Mean over folds and environments", cex.names = 0.85)
arrows(bp, rbind(m1 - s1, m2 - s2), bp, rbind(m1 + s1, m2 + s2), angle = 90, code = 3, length = 0.03)
points(bp, rbind(t1, t2), pch = 23, bg = "white", cex = 1.1)
legend("topleft", c("one-stage", "two-stage"), fill = c(col1, col2), border = NA, bty = "n", cex = 0.8, ncol = 2)
legend("topright", "accuracy (true value)", pch = 23, bty = "n", cex = 0.8)
dev.off()

## ---------- Figure 9: time ----------
has5 <- ex("results/e5_scaling.rds")
png2("figs/Figure9_time.png", 10, 4.2)
par(mfrow = c(1, 2), mar = c(4.3, 4.8, 3, 1), las = 1)
lt <- unique(paste(Tt$scheme, Tt$model))
lt <- lt[order(match(sub(" .*", "", lt), c("CV1", "CV2", "CV0")), lt)]
T1 <- sapply(lt, function(l) Tt$total[paste(Tt$scheme, Tt$model) == l & Tt$approach == "one-stage"])
T2 <- sapply(lt, function(l) Tt$total[paste(Tt$scheme, Tt$model) == l & Tt$approach == "two-stage"])
bp <- barplot(rbind(T1, T2) / 60, beside = TRUE, col = c(col1, col2), border = NA, names.arg = sub(" ", "\n", lt),
              ylab = "Total cross-validation time (min)", main = "(a) Cross-validation time (3,600 plots)", ylim = c(0, max(T1) / 60 * 1.2), cex.names = 0.85)
text(colMeans(bp), pmax(T1, T2) / 60, sprintf("%.1fx", T1 / T2), pos = 3, cex = 0.85)
legend("topright", c("one-stage", "two-stage"), fill = c(col1, col2), bty = "n", border = NA, cex = 0.85)
vals$cv_speed <- round(range(T1 / T2), 1)
if (has5) {
  e5 <- readRDS("results/e5_scaling.rds"); tabs$e5 <- e5
  plot(NA, xlim = range(e5$n_gen), ylim = range(c(e5$t_one, e5$t_two)), log = "y", xlab = "Number of lines (4 environments)",
       ylab = "Elapsed time of one fit (s, log scale)", main = "(b) Scaling of computing time")
  for (r in c(2, 3)) {
    d <- e5[e5$n_rep == r, ]; lty <- if (r == 2) 2 else 1
    lines(d$n_gen, d$t_one, type = "b", pch = 16, col = col1, lty = lty, lwd = 2)
    lines(d$n_gen, d$t_two, type = "b", pch = 17, col = col2, lty = lty, lwd = 2)
  }
  legend("topleft", c("one-stage, 3 reps", "one-stage, 2 reps", "two-stage, 3 reps", "two-stage, 2 reps"),
         col = c(col1, col1, col2, col2), lty = c(1, 2, 1, 2), pch = c(16, 16, 17, 17), lwd = 2, bty = "n", cex = 0.8)
  vals$scal_ratio <- round(range(e5$t_one / e5$t_two), 1)
  vals$scal_cor <- signif(min(e5$cor), 6)
}
dev.off()

## ---------- scalar values ----------
Y <- wheat599$Y; cc <- cor(Y)[upper.tri(diag(4))]
vals$wheat_cor_range <- sprintf("%.2f to %.2f", min(cc), max(cc))
G <- kernel_linear(wheat599$X); vals$G_offdiag <- sprintf("%.3f (SD = %.3f)", mean(G[upper.tri(G)]), sd(G[upper.tri(G)]))
allcor <- c(tabs$e4_full_stats$cor_12, if (has5) e5$cor)
vals$cor_min <- sprintf("%.4f", floor(min(allcor) * 1e4) / 1e4)
sp <- c(tabs$e4_full_stats$t_one / tabs$e4_full_stats$t_two, T1 / T2, if (has5) e5$t_one / e5$t_two)
vals$speed_range <- sprintf("%.1f to %.1f", min(sp), max(sp))
## printed output of example 2
d <- data.frame(gen = rownames(Y), y = Y[, "E1"])
fit_g <- gp_fit(y ~ 1, d, ETA = list(G = list(id = "gen", K = G, model = "GBLUP")))
vals$print_fit_g <- capture.output(print(fit_g))
saveRDS(tabs, "results/tables.rds")
jsonlite_ok <- requireNamespace("jsonlite", quietly = TRUE)
writeLines(jsonlite::toJSON(vals, auto_unbox = TRUE, pretty = TRUE, digits = NA), "article/vals.json")
print(tabs)
str(vals)
