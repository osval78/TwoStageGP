suppressMessages(library(TwoStageGP, lib.loc = "/home/claude/rlib2"))
data(wheat599)
X <- wheat599$X; Y <- wheat599$Y
G <- kernel_linear(X); KG <- kernel_gaussian(X, h = 1); E <- kernel_identity(colnames(Y))
d <- data.frame(gen = rep(rownames(Y), 4), env = rep(colnames(Y), each = 599), y = as.vector(Y))
models <- list(
  "GBLUP: E + G"      = list(G = list(id = "gen", K = G)),
  "GBLUP: E + G + GE" = list(G = list(id = "gen", K = G), GE = list(id = c("gen", "env"), K = list(G, E))),
  "RKHS: E + G + GE"  = list(G = list(id = "gen", K = KG), GE = list(id = c("gen", "env"), K = list(KG, E))))
ff <- "results/e3_full.rds"; full <- if (file.exists(ff)) readRDS(ff) else list()
for (m in setdiff(names(models), names(full))) {
  f <- gp_fit(y ~ env, d, models[[m]])
  full[[m]] <- list(varcomp = f$varcomp, time = f$time, AIC = f$AIC, logLik = f$logLik)
  saveRDS(full, ff); cat(m, "full", round(f$time, 1), "\n")
}
fc <- "results/e3_multi_env_cv.rds"
out <- if (file.exists(fc)) split(readRDS(fc), paste(readRDS(fc)$scheme, readRDS(fc)$model)) else list()
for (s in c("CV1", "CV2")) {
  part <- cv_partition(d, "gen", "env", s, folds = 5, seed = 2024)
  for (m in names(models)[1:2]) {
    if (paste(s, m) %in% names(out)) next
    cv <- gp_cv(d, "y", "gen", "env", ETA = models[[m]], partition = part, approach = "two-stage", verbose = TRUE)
    out[[paste(s, m)]] <- data.frame(scheme = s, model = m, cv$metrics, time = cv$time["total"])
    saveRDS(do.call(rbind, out), fc)
  }
}
cat("E3 finished\n")
