Scripts that reproduce the analyses and figures of the article
"A two stage genomic prediction library for genomic prediction" (TwoStageGP 0.1.1).
Install TwoStageGP first, and adapt lib.loc / paths if needed (scripts use /home/claude/rlib2).

e2_only.R          single-environment CV on wheat599 (GBLUP, RR, RKHS, G+A)
e3_resumable.R     multi-environment full fits on wheat599
e3_folds.R         multi-environment CV1/CV2 (fold-by-fold, resumable)
e4_sim.R           one-stage vs two-stage on simulated plot data (full fits + CV1, CV2, CV0)
e5_scaling.R       computing-time scaling (100-400 lines, 2-3 reps)
fig1.py, fig2_3.R  Figures 1-3;  results.R  Figures 4-9 and tables;  article_vals.R  numbers used in the text
e1_validation_rrBLUP.R  validation against rrBLUP (Table 3, Figure 4); its E2 part is superseded by e2_only.R
