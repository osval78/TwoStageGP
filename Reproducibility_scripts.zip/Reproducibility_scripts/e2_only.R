suppressMessages(library(TwoStageGP, lib.loc = "/home/claude/rlib2"))
data(wheat599)
X <- wheat599$X; Y <- wheat599$Y; A <- wheat599$A
G <- kernel_linear(X); KG <- kernel_gaussian(X, h = 1)
KG3 <- kernel_gaussian(X, h = c(0.25, 1, 4))
envs <- colnames(Y)
cat(as.character(packageVersion("TwoStageGP", lib.loc="/home/claude/rlib2")), "\n")
## E2: single-environment CV (random 5-fold) GBLUP, RR, RKHS, multi-kernel RKHS, G+A
models <- list(GBLUP = list(G = list(id = "gen", K = G, model = "GBLUP")),
               RR    = list(M = list(id = "gen", X = X, model = "RR")),
               RKHS  = list(K = list(id = "gen", K = KG, model = "RKHS")),
               GA    = list(G = list(id = "gen", K = G), A = list(id = "gen", K = A, model = "K")))
res <- list()
for (e in envs) {
  d <- data.frame(gen = rownames(Y), env = e, y = Y[, e])
  part <- cv_partition(d, "gen", "env", "random", folds = 5, seed = 2024)
  for (m in names(models)) {
    cv <- gp_cv(d, "y", "gen", "env", ETA = models[[m]], partition = part,
                approach = "two-stage", fixed = y ~ 1, verbose = FALSE)
    res[[paste(e, m)]] <- data.frame(env = e, model = m, cv$metrics, time = cv$time["total"])
    cat(e, m, round(mean(cv$metrics$cor), 3), round(cv$time["total"], 1), "\n")
  }
}
saveRDS(do.call(rbind, res), "results/e2_single_env_cv.rds")
