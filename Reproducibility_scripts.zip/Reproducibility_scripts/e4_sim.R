suppressMessages(library(TwoStageGP))
data(wheat599)
ng <- 300
X <- wheat599$X[1:ng, ]
sim <- simulate_met(X, n_env = 4, n_rep = 3, seed = 123)
saveRDS(sim, "results/sim_data.rds")
G <- kernel_linear(X); KG <- kernel_gaussian(X, h = 1); E <- kernel_identity(paste0("E", 1:4))
models <- list(GBLUP = list(G = list(id = "gen", K = G), GE = list(id = c("gen", "env"), K = list(G, E))),
               RKHS  = list(G = list(id = "gen", K = KG), GE = list(id = c("gen", "env"), K = list(KG, E))))
## full-data fits
full <- list()
for (m in names(models)) {
  one <- one_stage(sim$data, "yield", "gen", "env", "rep", ETA = models[[m]])
  two <- two_stage(sim$data, "yield", "gen", "env", "rep", ETA = models[[m]], weighting = "none")
  twow <- two_stage(sim$data, "yield", "gen", "env", "rep", ETA = models[[m]])
  cs <- compare_stages(one, two); csw <- compare_stages(one, twow)
  tr <- sim$truth$tgv[match(paste(cs$predictions$gen, cs$predictions$env), paste(sim$truth$gen, sim$truth$env))]
  full[[m]] <- list(cmp = cs, cmpw = csw, truth = tr, one_vc = one$varcomp, two_vc = two$varcomp,
                    twow_vc = twow$varcomp, time = c(one = one$time_total, two = two$time_total, twow = twow$time_total,
                    s1 = two$time_stage1, s2 = two$time_stage2), aic = c(one$AIC, two$AIC))
  cat(m, "cor", cs$cor, "time", cs$time, "\n")
  saveRDS(full, "results/e4_full.rds")
}
## cross-validation
cvres <- list()
plan <- list(c("CV1", "GBLUP"), c("CV2", "GBLUP"), c("CV0", "GBLUP"), c("CV1", "RKHS"), c("CV2", "RKHS"))
for (pl in plan) {
  part <- cv_partition(sim$data, "gen", "env", pl[1], folds = 5, seed = 7)
  for (ap in c("two-stage", "one-stage")) {
    cv <- gp_cv(sim$data, "yield", "gen", "env", "rep", ETA = models[[pl[2]]], partition = part,
                approach = ap, truth = "tgv", weighting = "none", verbose = TRUE)
    cvres[[paste(pl[1], pl[2], ap)]] <- list(metrics = data.frame(scheme = pl[1], model = pl[2], approach = ap, cv$metrics),
                                             predictions = data.frame(scheme = pl[1], model = pl[2], approach = ap, cv$predictions),
                                             time = cv$time, fold_times = cv$fold_times)
    saveRDS(cvres, "results/e4_cv.rds")
  }
}
cat("E4 CV finished\n")
