suppressMessages(library(TwoStageGP, lib.loc = "/home/claude/rlib2"))
data(wheat599)
G <- kernel_linear(wheat599$X); K <- kernel_gaussian(wheat599$X, h = 1); A <- wheat599$A
ord <- hclust(as.dist(1 - cor(G)), method = "average")$order
pal <- colorRampPalette(c("#2c7bb6", "#abd9e9", "#ffffbf", "#fdae61", "#d7191c"))(200)
png("figs/Figure2_kernels.png", width = 7.5, height = 6.6, units = "in", res = 600)
layout(matrix(1:4, 2, byrow = TRUE)); par(mar = c(2.5, 2.5, 3, 1), cex.main = 1)
hm <- function(M, main) {
  image(seq_len(nrow(M)), seq_len(nrow(M)), M[ord, rev(ord)], col = pal, axes = FALSE, xlab = "", ylab = "", main = main, useRaster = TRUE)
  box(); mtext("lines (clustered)", 1, 0.6, cex = 0.7); mtext("lines", 2, 0.6, cex = 0.7)
}
hm(G, "(a) Genomic kernel G (GBLUP)")
hm(K, "(b) Gaussian kernel, h = 1 (RKHS)")
hm(A, "(c) Pedigree relationship A")
eg <- eigen(G, TRUE, only.values = TRUE)$values; ek <- eigen(K, TRUE, only.values = TRUE)$values; ea <- eigen(A, TRUE, only.values = TRUE)$values
cp <- function(v) cumsum(pmax(v, 0)) / sum(pmax(v, 0))
par(mar = c(4, 4, 3, 1))
plot(cp(eg), type = "l", lwd = 2, col = "#d7191c", xlab = "Number of eigenvectors", ylab = "Cumulative proportion of trace",
     main = "(d) Spectrum of the kernels", ylim = c(0, 1), las = 1)
lines(cp(ek), lwd = 2, col = "#2c7bb6"); lines(cp(ea), lwd = 2, col = "#1a9641", lty = 2)
abline(h = c(0.9, 0.99), lty = 3, col = "grey50")
legend("bottomright", c("G (linear)", "Gaussian (h = 1)", "Pedigree A"), col = c("#d7191c", "#2c7bb6", "#1a9641"), lwd = 2, lty = c(1, 1, 2), bty = "n", cex = 0.85)
dev.off()
cat("eigvec for 90/99%:", which(cp(eg) >= .9)[1], which(cp(eg) >= .99)[1], which(cp(ek) >= .9)[1], which(cp(ek) >= .99)[1], "\n")
cat("offdiag summaries G K A:", round(c(mean(G[upper.tri(G)]), sd(G[upper.tri(G)]), mean(K[upper.tri(K)]), mean(A[upper.tri(A)])), 3), "\n")
cat("cor offdiag G-A", round(cor(G[upper.tri(G)], A[upper.tri(A)]), 3), " G-K", round(cor(G[upper.tri(G)], K[upper.tri(K)]), 3), "\n")
## Figure 3: CV schemes on a toy layout
d <- expand.grid(gen = sprintf("G%02d", 1:12), env = paste0("E", 1:4), stringsAsFactors = FALSE)
sch <- c("CV1", "CV2", "CV0", "CV00", "random")
tt <- c(CV1 = "CV1: untested lines", CV2 = "CV2: sparse testing", CV0 = "CV0: untested environment",
        CV00 = "CV00: untested lines in\nuntested environment", random = "Random k-fold")
png("figs/Figure3_cv_schemes.png", width = 10, height = 4.4, units = "in", res = 600)
par(mfrow = c(1, 5), mar = c(3.5, 3.5, 4, 0.6))
for (s in sch) {
  p <- cv_partition(d, "gen", "env", s, folds = 4, seed = 3)
  f <- p$folds[[1]]
  st <- ifelse(p$combos$key %in% f$test, 2, ifelse(p$combos$key %in% f$train, 1, 0))
  M <- matrix(st, 12, 4)
  image(1:4, 1:12, t(M)[, 12:1], col = c("grey80", "#4575b4", "#d73027"), zlim = c(0, 2), axes = FALSE, xlab = "", ylab = "", main = tt[s], cex.main = 0.95)
  abline(v = 0.5:4.5, h = 0.5:12.5, col = "white", lwd = 1.5)
  axis(1, 1:4, paste0("E", 1:4), tick = FALSE, line = -0.6, cex.axis = 0.9)
  axis(2, 1:12, rev(sprintf("G%02d", 1:12)), las = 1, tick = FALSE, line = -0.6, cex.axis = 0.75)
}
par(fig = c(0, 1, 0, 1), new = TRUE, mar = c(0, 0, 0, 0)); plot.new()
legend("bottom", c("training", "testing (fold 1)", "excluded"), fill = c("#4575b4", "#d73027", "grey80"), horiz = TRUE, bty = "n", cex = 1, inset = 0)
dev.off()
