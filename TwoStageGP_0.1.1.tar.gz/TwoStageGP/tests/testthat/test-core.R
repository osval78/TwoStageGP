data(wheat599)
X <- wheat599$X[1:80, ]
G <- kernel_linear(X)

test_that("kernels have the right shape and names", {
  expect_equal(dim(G), c(80, 80))
  expect_identical(rownames(G), rownames(X))
  K <- kernel_gaussian(X, h = c(0.5, 1))
  expect_length(K, 2)
  expect_true(all(abs(diag(K[[1]]) - 1) < 1e-12))
  L <- factor_K(G)
  expect_lt(max(abs(as.matrix(Matrix::tcrossprod(L)) - G)), 1e-4)
})

test_that("GBLUP and RR terms give identical predictions", {
  d <- data.frame(gen = rownames(X), y = wheat599$Y[1:80, 1])
  f1 <- gp_fit(y ~ 1, d, list(G = list(id = "gen", K = G)))
  f2 <- gp_fit(y ~ 1, d, list(M = list(id = "gen", X = X, model = "RR")))
  expect_lt(max(abs(f1$random$G - f2$random$M)), 1e-6)
  Xs <- scale(clean_markers(X))
  expect_lt(max(abs(as.vector(Xs %*% f2$marker_effects$M) - f2$random$M)), 1e-6)
})

test_that("lines without phenotypes are predicted", {
  d <- data.frame(gen = rownames(X), y = wheat599$Y[1:80, 1])
  d$y[1:20] <- NA
  f <- gp_fit(y ~ 1, d, list(G = list(id = "gen", K = G)))
  p <- predict(f, d[1:20, ])
  expect_length(p, 20)
  expect_false(anyNA(p))
})

test_that("one-stage and two-stage agree on balanced data", {
  sim <- simulate_met(X, n_env = 2, n_rep = 2, seed = 3)
  E <- kernel_identity(c("E1", "E2"))
  ETA <- list(G = list(id = "gen", K = G), GE = list(id = c("gen", "env"), K = list(G, E)))
  f1 <- one_stage(sim$data, "yield", "gen", "env", "rep", ETA = ETA)
  f2 <- two_stage(sim$data, "yield", "gen", "env", "rep", ETA = ETA, weighting = "none")
  cs <- compare_stages(f1, f2)
  expect_gt(cs$cor, 0.99)
})

test_that("cross-validation partitions are valid", {
  d <- expand.grid(gen = paste0("G", 1:20), env = paste0("E", 1:4), stringsAsFactors = FALSE)
  for (s in c("CV1", "CV2", "CV0", "CV00", "random")) {
    p <- cv_partition(d, "gen", "env", s, folds = 5, seed = 1)
    for (f in p$folds) expect_length(intersect(f$test, f$train), 0)
  }
  p2 <- cv_partition(d, "gen", "env", "CV2", folds = 5, seed = 1)
  tested <- unlist(lapply(p2$folds, `[[`, "test"))
  expect_equal(sort(tested), sort(p2$combos$key))
  p1 <- cv_partition(d, "gen", "env", "CV1", folds = 5, seed = 1)
  g_test <- sub("\r.*", "", p1$folds[[1]]$test)
  g_train <- sub("\r.*", "", p1$folds[[1]]$train)
  expect_length(intersect(g_test, g_train), 0)
})

test_that("gp_cv works with a fixed formula without environment", {
  d <- data.frame(gen = rownames(X), env = "E1", y = wheat599$Y[1:80, 1])
  p <- cv_partition(d, "gen", "env", "random", folds = 4, seed = 1)
  cv <- gp_cv(d, "y", "gen", "env", ETA = list(G = list(id = "gen", K = G)),
              partition = p, fixed = y ~ 1, verbose = FALSE)
  expect_equal(nrow(cv$metrics), 4)
  expect_false(anyNA(cv$metrics$cor))
})
