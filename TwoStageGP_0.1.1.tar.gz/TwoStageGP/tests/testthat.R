library(testthat)
library(TwoStageGP)
test_check("TwoStageGP")
