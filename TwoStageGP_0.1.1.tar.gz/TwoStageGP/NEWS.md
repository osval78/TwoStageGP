# TwoStageGP 0.1.0
* First release: gp_fit(), one_stage(), stage1(), two_stage(), kernels, cross-validation
  schemes (CV1, CV2, CV0, CV00, random), simulate_met() and the wheat599 data.

# TwoStageGP 0.1.1
* gp_cv(): environment means for the response scale are now computed from the training
  records, so fixed formulas without the environment column (e.g. y ~ 1) work.
