## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 6, fig.height = 4)

## -----------------------------------------------------------------------------
library(TwoStageGP)
data(wheat599)
dim(wheat599$X)        # 599 lines x 1279 DArT markers
head(wheat599$Y, 3)    # standardised grain yield, 4 environments

## -----------------------------------------------------------------------------
G  <- kernel_linear(wheat599$X)              # GBLUP kernel (standardised markers)
KG <- kernel_gaussian(wheat599$X, h = 1)     # RKHS Gaussian kernel
A  <- wheat599$A                             # pedigree relationship matrix
round(G[1:3, 1:3], 3)

## -----------------------------------------------------------------------------
d <- data.frame(gen = rownames(wheat599$Y), y = wheat599$Y[, "E1"])
fit_g <- gp_fit(y ~ 1, d, ETA = list(G = list(id = "gen", K = G, model = "GBLUP")))
fit_g

## -----------------------------------------------------------------------------
fit_rr <- gp_fit(y ~ 1, d, ETA = list(M = list(id = "gen", X = wheat599$X, model = "RR")))
max(abs(gp_effects(fit_g) - gp_effects(fit_rr)))
head(fit_rr$marker_effects$M)

## -----------------------------------------------------------------------------
fit_ga <- gp_fit(y ~ 1, d, ETA = list(G = list(id = "gen", K = G),
                                      A = list(id = "gen", K = A, model = "K")))
varcomp(fit_ga)

## -----------------------------------------------------------------------------
d2 <- d; d2$y[1:100] <- NA
f <- gp_fit(y ~ 1, d2, ETA = list(G = list(id = "gen", K = KG, model = "RKHS")))
cor(predict(f, d[1:100, ]), d$y[1:100])

## -----------------------------------------------------------------------------
Xs  <- wheat599$X[1:120, ]
sim <- simulate_met(Xs, n_env = 4, n_rep = 2, seed = 10)
head(sim$data)
Gs  <- kernel_linear(Xs)
E   <- kernel_identity(paste0("E", 1:4))
ETA <- list(G  = list(id = "gen", K = Gs),
            GE = list(id = c("gen", "env"), K = list(Gs, E)))

## -----------------------------------------------------------------------------
one <- one_stage(sim$data, y = "yield", gen = "gen", env = "env", rep = "rep", ETA = ETA)
two <- two_stage(sim$data, y = "yield", gen = "gen", env = "env", rep = "rep", ETA = ETA)
cmp <- compare_stages(one, two)
cmp$cor            # correlation between one-stage and two-stage predictions
cmp$varcomp
cmp$time

## -----------------------------------------------------------------------------
two$stage1

## -----------------------------------------------------------------------------
p1 <- cv_partition(sim$data, "gen", "env", scheme = "CV1", folds = 5, seed = 1)
p2 <- cv_partition(sim$data, "gen", "env", scheme = "CV2", folds = 5, seed = 1)
p1; p2

## ----message = FALSE----------------------------------------------------------
cv_two <- gp_cv(sim$data, "yield", "gen", "env", "rep", ETA = ETA, partition = p1,
                approach = "two-stage", truth = "tgv", verbose = FALSE)
cv_one <- gp_cv(sim$data, "yield", "gen", "env", "rep", ETA = ETA, partition = p1,
                approach = "one-stage", truth = "tgv", verbose = FALSE)
compare_cv(two_stage = cv_two, one_stage = cv_one)

## ----fig.height = 3.5---------------------------------------------------------
oldpar <- par(mfrow = c(1, 2)); plot(cv_one); plot(cv_two); par(oldpar)

