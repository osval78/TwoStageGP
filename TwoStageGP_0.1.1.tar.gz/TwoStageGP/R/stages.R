#' Stage 1: genotype BLUEs within each environment
#'
#' Fits, separately in each environment, a model with genotypes as fixed
#' effects and the experimental design terms, and returns the best linear
#' unbiased estimates (BLUEs) of the genotype means, their standard errors and
#' the weights used in stage 2.
#'
#' Default stage-1 models (\code{y}, \code{gen}, \code{rep} and \code{block}
#' denote the generic columns):
#' \itemize{
#'   \item no \code{rep}, no \code{block}: \code{y ~ 0 + gen} (genotype means);
#'   \item \code{rep} only (RCBD): \code{y ~ 0 + gen + rep} (sum-to-zero
#'     contrasts for \code{rep}), fitted with \code{lm};
#'   \item \code{block} (incomplete blocks within replicates, e.g. alpha
#'     lattice): \code{y ~ 0 + gen + rep + (1|rep:block)}, fitted with
#'     \code{lme4::lmer}.
#' }
#' A custom model can be given in \code{formula} using the generic names
#' \code{y}, \code{gen}, \code{rep} and \code{block}; it must contain
#' \code{0 + gen}.
#'
#' @param data Plot-level data frame.
#' @param y,gen,env,rep,block Column names of the response, genotype,
#'   environment, replicate and incomplete block (the last three optional).
#' @param formula Optional custom stage-1 formula (see Details).
#' @param weighting \code{"inverse_variance"} (default): stage-2 weights
#'   \eqn{w_{ij} \propto 1/\mathrm{SE}^2_{ij}} scaled to mean one (Smith et al.,
#'   2001); \code{"none"}: all weights equal to one.
#' @return An object of class \code{"gpstage1"}: a list with \code{blues} (data
#'   frame with columns \code{gen}, \code{env}, the response name holding the
#'   BLUE, \code{SE} and \code{w}), \code{env_summary} and \code{time}.
#' @references Smith, A., Cullis, B., & Gilmour, A. (2001). The analysis of
#'   crop variety evaluation data in Australia. \emph{Australian & New Zealand
#'   Journal of Statistics, 43}, 129-145.
#' @export
#' @examples
#' data(wheat599)
#' sim <- simulate_met(wheat599$X[1:60, ], n_env = 2, n_rep = 2, seed = 1)
#' s1 <- stage1(sim$data, y = "yield", gen = "gen", env = "env", rep = "rep")
#' head(s1$blues)
stage1 <- function(data, y, gen, env = NULL, rep = NULL, block = NULL,
                   formula = NULL, weighting = c("inverse_variance", "none")) {
  weighting <- match.arg(weighting)
  t0 <- proc.time()[["elapsed"]]
  data <- as.data.frame(data)
  envs <- if (is.null(env)) "all" else sort(unique(as.character(data[[env]])))
  res <- list(); summ <- list()
  for (e in envs) {
    de <- if (is.null(env)) data else data[as.character(data[[env]]) == e, , drop = FALSE]
    de <- de[!is.na(de[[y]]), , drop = FALSE]
    d <- data.frame(y = de[[y]], gen = factor(as.character(de[[gen]])))
    if (!is.null(rep)) d$rep <- factor(de[[rep]])
    if (!is.null(block)) d$block <- factor(de[[block]])
    nrep <- if (is.null(rep)) 1 else nlevels(d$rep)
    if (is.null(formula)) {
      f <- if (!is.null(block)) {
        if (nrep > 1) y ~ 0 + gen + rep + (1 | rep:block) else y ~ 0 + gen + (1 | block)
      } else if (nrep > 1) y ~ 0 + gen + rep else y ~ 0 + gen
    } else f <- stats::as.formula(formula)
    ctr <- if (!is.null(rep) && nrep > 1) list(rep = "contr.sum") else NULL
    if (is.null(lme4::findbars(f))) {
      m <- stats::lm(f, data = d, contrasts = ctr)
      b <- stats::coef(m)
      V <- if (m$df.residual > 0) diag(stats::vcov(m)) else rep(NA_real_, length(b))
      names(V) <- names(b)
      s2 <- if (m$df.residual > 0) summary(m)$sigma^2 else NA_real_
    } else {
      m <- lme4::lmer(f, data = d, contrasts = ctr, REML = TRUE)
      b <- lme4::fixef(m)
      V <- diag(as.matrix(stats::vcov(m))); names(V) <- names(b)
      s2 <- stats::sigma(m)^2
    }
    gi <- grepl("^gen", names(b))
    out <- data.frame(gen = sub("^gen", "", names(b)[gi]), env = e,
                      BLUE = unname(b[gi]), SE = sqrt(unname(V[gi])),
                      stringsAsFactors = FALSE)
    res[[e]] <- out
    summ[[e]] <- data.frame(env = e, n_plots = nrow(d), n_gen = nlevels(d$gen),
                            mean = mean(d$y), sigma2_e = s2,
                            mean_SE2 = mean(out$SE^2))
  }
  bl <- do.call(rbind, res); rownames(bl) <- NULL
  v <- bl$SE^2
  bl$w <- if (weighting == "none" || all(is.na(v))) 1 else {
    vv <- ifelse(is.na(v), mean(v, na.rm = TRUE), v)
    mean(vv) / vv
  }
  names(bl)[names(bl) == "gen"] <- gen
  if (!is.null(env)) names(bl)[names(bl) == "env"] <- env else bl$env <- NULL
  names(bl)[names(bl) == "BLUE"] <- y
  es <- do.call(rbind, summ); rownames(es) <- NULL
  out <- list(blues = bl, env_summary = es, y = y, gen = gen, env = env,
              weighting = weighting, time = proc.time()[["elapsed"]] - t0)
  class(out) <- "gpstage1"
  out
}

#' @export
print.gpstage1 <- function(x, ...) {
  cat("Stage 1: genotype BLUEs within environments\n")
  cat("  records:", nrow(x$blues), " weighting:", x$weighting,
      " time:", sprintf("%.2f s", x$time), "\n")
  print(x$env_summary, digits = 4, row.names = FALSE)
  invisible(x)
}

.default_fixed <- function(y, env, rep, block, stage) {
  bt <- function(v) paste0("`", v, "`")
  rhs <- character(0)
  if (!is.null(env)) rhs <- c(rhs, bt(env))
  if (stage == 1) {
    if (!is.null(rep)) rhs <- c(rhs, if (!is.null(env)) paste0(bt(env), ":", bt(rep)) else bt(rep))
    if (!is.null(block)) {
      g <- paste(bt(c(env, rep, block)), collapse = ":")
      rhs <- c(rhs, paste0("(1|", g, ")"))
    }
  }
  if (!length(rhs)) rhs <- "1"
  stats::as.formula(paste(bt(y), "~", paste(rhs, collapse = " + ")))
}

#' One-stage genomic prediction (plot-level model)
#'
#' Fits the genomic model directly to plot-level records, jointly with the
#' design effects. By default the fixed part is
#' \code{y ~ env + env:rep} and, if \code{block} is given, the random term
#' \code{(1|env:rep:block)} is added.
#'
#' @param data Plot-level data frame.
#' @param y,gen,env,rep,block Column names (see \code{\link{stage1}}).
#' @param ETA List of genomic/environmental terms (see \code{\link{prepare_ETA}}).
#' @param fixed Optional formula replacing the default fixed/design part.
#' @param ... Further arguments for \code{\link{gp_fit}}.
#' @return An object of class \code{"gpfit"} (with \code{approach = "one-stage"}).
#' @export
#' @examples
#' data(wheat599)
#' sim <- simulate_met(wheat599$X[1:60, ], n_env = 2, n_rep = 2, seed = 1)
#' G <- kernel_linear(wheat599$X[1:60, ])
#' f1 <- one_stage(sim$data, "yield", "gen", "env", "rep",
#'                 ETA = list(G = list(id = "gen", K = G)))
#' f1$varcomp
one_stage <- function(data, y, gen, env = NULL, rep = NULL, block = NULL,
                      ETA, fixed = NULL, ...) {
  t0 <- proc.time()[["elapsed"]]
  form <- if (is.null(fixed)) .default_fixed(y, env, rep, block, 1) else stats::as.formula(fixed)
  fit <- gp_fit(form, data, ETA = ETA, ...)
  fit$approach <- "one-stage"
  fit$gen <- gen; fit$env <- env
  fit$time_total <- proc.time()[["elapsed"]] - t0
  fit
}

#' Two-stage genomic prediction (BLUEs, then genomic model)
#'
#' Stage 1 (\code{\link{stage1}}) computes genotype BLUEs within environments;
#' stage 2 fits the genomic model (\code{\link{gp_fit}}) to the BLUEs with
#' residual weights. By default the stage-2 fixed part is \code{BLUE ~ env}.
#'
#' @inheritParams one_stage
#' @param weighting Stage-2 weights: \code{"inverse_variance"} or \code{"none"}.
#' @param stage1_formula Optional custom stage-1 formula.
#' @return An object of class \code{"gpfit"} with additional elements
#'   \code{stage1} (the \code{"gpstage1"} object), \code{time_stage1},
#'   \code{time_stage2} and \code{time_total}.
#' @export
#' @examples
#' data(wheat599)
#' sim <- simulate_met(wheat599$X[1:60, ], n_env = 2, n_rep = 2, seed = 1)
#' G <- kernel_linear(wheat599$X[1:60, ])
#' f2 <- two_stage(sim$data, "yield", "gen", "env", "rep",
#'                 ETA = list(G = list(id = "gen", K = G)))
#' f2$varcomp
two_stage <- function(data, y, gen, env = NULL, rep = NULL, block = NULL,
                      ETA, fixed = NULL, weighting = c("inverse_variance", "none"),
                      stage1_formula = NULL, ...) {
  weighting <- match.arg(weighting)
  t0 <- proc.time()[["elapsed"]]
  s1 <- stage1(data, y, gen, env, rep, block, formula = stage1_formula, weighting = weighting)
  form <- if (is.null(fixed)) .default_fixed(y, env, NULL, NULL, 2) else stats::as.formula(fixed)
  fit <- gp_fit(form, s1$blues, ETA = ETA, weights = s1$blues$w, ...)
  fit$approach <- "two-stage"
  fit$gen <- gen; fit$env <- env
  fit$stage1 <- s1
  fit$time_stage1 <- s1$time
  fit$time_stage2 <- fit$time
  fit$time_total <- proc.time()[["elapsed"]] - t0
  fit
}
