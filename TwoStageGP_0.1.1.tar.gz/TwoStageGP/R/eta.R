#' Factorise a covariance matrix as K = L L'
#'
#' By default (\code{method = "chol"}) the lower-triangular Cholesky factor is
#' used, which keeps about half of the entries of \eqn{L} equal to zero and
#' makes \pkg{lme4} roughly three times faster than a dense factor. Singular
#' kernels (e.g. a genomic matrix from centred markers) receive a tiny ridge
#' (\code{jitter} times the mean diagonal) before factorisation. With
#' \code{method = "eigen"}, \eqn{L = U D^{1/2}} keeps the eigenvalues larger than
#' \code{tol * max(eigenvalue)} or, if \code{prop_var < 1}, the leading
#' eigenvectors that explain that proportion of the trace (a low-rank
#' approximation that further reduces computing time). Diagonal matrices are
#' always handled sparsely.
#'
#' @param K Symmetric positive semi-definite matrix.
#' @param method \code{"chol"} (default) or \code{"eigen"}.
#' @param tol Relative tolerance for eigenvalues (\code{method = "eigen"}).
#' @param prop_var Proportion of the trace kept (\code{method = "eigen"}).
#' @param jitter Relative ridge added when \code{K} is not positive definite.
#' @return A sparse \code{Matrix} with \code{nrow(K)} rows.
#' @export
#' @examples
#' K <- kernel_identity(letters[1:3]); factor_K(K)
factor_K <- function(K, method = c("chol", "eigen"), tol = 1e-8, prop_var = 1,
                     jitter = 1e-6) {
  method <- match.arg(method)
  K <- as.matrix(K)
  if (!isSymmetric(unname(K), tol = 1e-6)) stop("Kernel matrix is not symmetric.")
  offd <- K; diag(offd) <- 0
  if (all(abs(offd) < 1e-12)) {
    d <- diag(K)
    keep <- d > tol * max(d)
    L <- Matrix::sparseMatrix(i = which(keep), j = seq_len(sum(keep)),
                              x = sqrt(d[keep]), dims = c(nrow(K), sum(keep)))
    return(L)
  }
  if (method == "chol" && prop_var >= 1) {
    R <- tryCatch(chol(K), error = function(e) NULL)
    j <- jitter
    while (is.null(R) && j < 1e-2) {
      R <- tryCatch(chol(K + diag(j * mean(diag(K)), nrow(K))), error = function(e) NULL)
      j <- j * 10
    }
    if (!is.null(R)) {
      return(.as_dgC(t(R)))
    }
    warning("Cholesky factorisation failed; using the eigen decomposition.")
  }
  e <- eigen(K, symmetric = TRUE)
  keep <- e$values > tol * max(e$values)
  if (prop_var < 1) {
    cv <- cumsum(pmax(e$values, 0)) / sum(pmax(e$values, 0))
    keep <- keep & seq_along(keep) <= which(cv >= prop_var)[1]
  }
  L <- e$vectors[, keep, drop = FALSE] %*% diag(sqrt(e$values[keep]), sum(keep))
  .as_dgC(L)
}

.as_dgC <- function(x) {
  x <- methods::as(Matrix::Matrix(x, sparse = TRUE), "CsparseMatrix")
  methods::as(x, "generalMatrix")
}

.make_key <- function(data, id, sep = ":") {
  if (length(id) == 1) return(as.character(data[[id]]))
  do.call(paste, c(lapply(id, function(v) as.character(data[[v]])), sep = sep))
}

#' Prepare the terms of the linear predictor
#'
#' Validates a BGLR-like list of terms (\code{ETA}) and factorises each
#' covariance matrix once, so that it can be reused across many model fits
#' (e.g. the folds of a cross-validation).
#'
#' Each element of \code{ETA} is a list with:
#' \describe{
#'   \item{\code{id}}{Name(s) of the column(s) of \code{data} that index the
#'     term, e.g. \code{"gen"} or \code{c("gen", "env")} for an interaction.}
#'   \item{\code{K}}{A relationship (kernel) matrix whose row names are the
#'     levels of \code{id}; or, for interaction terms, a list with one matrix
#'     per variable in \code{id} (the term covariance is their Kronecker
#'     product). An element equal to \code{NULL} or \code{"I"} means the
#'     identity matrix over the levels observed in \code{data}.}
#'   \item{\code{X}}{(Only for \code{model = "RR"}.) A marker matrix whose row
#'     names are the levels of \code{id}. Markers are standardised and the term
#'     is \eqn{u = X\beta}, \eqn{\beta \sim N(0, \sigma^2_\beta I)}.}
#'   \item{\code{model}}{One of \code{"GBLUP"}, \code{"RKHS"}, \code{"K"}
#'     (synonyms: a term with a user-supplied kernel), \code{"RR"} (ridge
#'     regression / RR-BLUP on \code{X}), or \code{"iid"} (independent
#'     effects). If omitted it is deduced from the supplied elements.}
#' }
#'
#' @param ETA Named list of terms (see Details).
#' @param data Data frame containing the \code{id} columns.
#' @param method,tol,prop_var Factorisation options passed to \code{\link{factor_K}}.
#' @return An object of class \code{"gpETA"}.
#' @export
#' @examples
#' data(wheat599)
#' G <- kernel_linear(wheat599$X)
#' d <- data.frame(gen = rownames(G)[1:20], y = rnorm(20))
#' pE <- prepare_ETA(list(G = list(id = "gen", K = G)), d)
#' pE
prepare_ETA <- function(ETA, data, method = c("chol", "eigen"), tol = 1e-8, prop_var = 1) {
  method <- match.arg(method)
  if (inherits(ETA, "gpETA")) return(ETA)
  if (!is.list(ETA) || length(ETA) == 0) stop("'ETA' must be a non-empty list of terms.")
  if (is.null(names(ETA)) || any(names(ETA) == ""))
    names(ETA) <- paste0("T", seq_along(ETA))
  out <- vector("list", length(ETA)); names(out) <- names(ETA)
  for (k in seq_along(ETA)) {
    tm <- ETA[[k]]
    nm <- names(ETA)[k]
    if (is.null(tm$id)) stop("Term '", nm, "' needs an 'id' element (column name(s) of data).")
    miss <- setdiff(tm$id, names(data))
    if (length(miss)) stop("Term '", nm, "': column(s) not found in data: ", paste(miss, collapse = ", "))
    model <- tm$model
    if (is.null(model)) model <- if (!is.null(tm$X)) "RR" else if (!is.null(tm$K)) "GBLUP" else "iid"
    model <- toupper(model)
    if (model == "BRR") model <- "RR"
    if (!model %in% c("GBLUP", "RKHS", "K", "RR", "IID"))
      stop("Term '", nm, "': unknown model '", tm$model, "'.")
    t0 <- proc.time()[["elapsed"]]
    p <- NA_integer_
    Xrr <- NULL
    if (model == "RR") {
      if (is.null(tm$X)) stop("Term '", nm, "': model 'RR' requires a marker matrix X.")
      if (length(tm$id) != 1) stop("Term '", nm, "': model 'RR' supports a single id variable.")
      if (is.null(rownames(tm$X))) stop("Term '", nm, "': X needs row names (level names).")
      # u = Xs b, b ~ N(0, s2/p I)  <=>  u ~ N(0, s2 Xs Xs'/p): fitted through the
      # linear kernel; marker effects are back-transformed after fitting.
      Xs <- scale(clean_markers(tm$X))
      p <- ncol(Xs)
      Kr <- tcrossprod(Xs) / p
      dimnames(Kr) <- list(rownames(tm$X), rownames(tm$X))
      L <- factor_K(Kr, method = method, tol = tol, prop_var = prop_var)
      levs <- rownames(tm$X)
      mnames <- colnames(Xs)
      Xrr <- Xs
    } else if (model == "IID") {
      levs <- sort(unique(.make_key(data, tm$id)))
      if (!is.null(tm$levels)) levs <- as.character(tm$levels)
      L <- Matrix::sparseMatrix(i = seq_along(levs), j = seq_along(levs), x = 1)
      mnames <- NULL
    } else {
      Kl <- tm$K
      if (!is.list(Kl)) Kl <- list(Kl)
      if (length(Kl) != length(tm$id))
        stop("Term '", nm, "': provide one matrix in K per variable in id (", length(tm$id), ").")
      Ls <- vector("list", length(Kl)); lv <- vector("list", length(Kl))
      for (j in seq_along(Kl)) {
        Kj <- Kl[[j]]
        if (is.null(Kj) || (is.character(Kj) && identical(toupper(Kj), "I"))) {
          lvj <- sort(unique(as.character(data[[tm$id[j]]])))
          Kj <- kernel_identity(lvj)
        }
        if (is.null(rownames(Kj))) stop("Term '", nm, "': kernel for '", tm$id[j], "' needs row names.")
        Ls[[j]] <- factor_K(Kj, method = method, tol = tol, prop_var = prop_var)
        lv[[j]] <- rownames(Kj)
      }
      L <- Ls[[1]]; levs <- lv[[1]]
      if (length(Ls) > 1) for (j in 2:length(Ls)) {
        L <- Matrix::kronecker(L, Ls[[j]])
        levs <- paste(rep(levs, each = length(lv[[j]])), rep(lv[[j]], times = length(levs)), sep = ":")
      }
      L <- .as_dgC(L)
      mnames <- NULL
    }
    key <- .make_key(data, tm$id)
    bad <- setdiff(unique(key), levs)
    if (length(bad)) stop("Term '", nm, "': ", length(bad), " level(s) of ", paste(tm$id, collapse = ":"),
                          " are not in the row names of the kernel, e.g. '", bad[1], "'.")
    out[[k]] <- list(name = nm, id = tm$id, model = model, L = L, levels = levs,
                     rank = ncol(L), p = p, marker_names = mnames, Xs = Xrr,
                     time = proc.time()[["elapsed"]] - t0)
  }
  class(out) <- "gpETA"
  out
}

#' @export
print.gpETA <- function(x, ...) {
  cat("Prepared linear predictor with", length(x), "term(s):\n")
  for (t in x) cat(sprintf("  %-8s id = %-12s model = %-6s levels = %5d  rank = %5d\n",
                           t$name, paste(t$id, collapse = ":"), t$model,
                           length(t$levels), t$rank))
  invisible(x)
}
