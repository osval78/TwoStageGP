#' Build cross-validation partitions used in genomic prediction
#'
#' Partitions are defined on the genotype x environment combinations present in
#' \code{data}, so the same partition can be applied to plot-level data
#' (one-stage) and to stage-1 BLUEs (two-stage).
#'
#' \describe{
#'   \item{\code{"CV1"}}{Untested genotypes: genotypes are split into
#'     \code{folds} groups; a fold tests all records of its genotypes in all
#'     environments (prediction of newly developed lines).}
#'   \item{\code{"CV2"}}{Incomplete field trials (sparse testing): each
#'     genotype has some environments in the test set and the remaining ones in
#'     the training set. Environments of each genotype are spread over
#'     different folds so that, when \code{folds >= n_env}, no genotype is
#'     masked in all environments of the same fold.}
#'   \item{\code{"CV0"}}{Untested environments: leave-one-environment-out;
#'     tested genotypes are predicted in a new environment.}
#'   \item{\code{"CV00"}}{Untested genotypes in untested environments: a fold
#'     is an (environment, genotype-group) pair; the training set excludes both
#'     the environment and the genotype group.}
#'   \item{\code{"random"}}{Random k-fold partition of the combinations.}
#' }
#'
#' @param data Data frame (plots or BLUEs).
#' @param gen,env Column names of genotype and environment.
#' @param scheme One of \code{"CV1"}, \code{"CV2"}, \code{"CV0"},
#'   \code{"CV00"}, \code{"random"}.
#' @param folds Number of folds (genotype groups for CV1/CV00).
#' @param seed Random seed.
#' @param max_folds Optional maximum number of folds kept (useful for CV00).
#' @return An object of class \code{"gppartition"}: a list with \code{scheme},
#'   \code{combos} (genotype, environment and \code{key}) and \code{folds}, a
#'   list whose elements contain the keys of the \code{test} and
#'   \code{train} combinations.
#' @references Burgueño, J., de los Campos, G., Weigel, K., & Crossa, J.
#'   (2012). Genomic prediction of breeding values when modeling
#'   genotype x environment interaction using pedigree and dense molecular
#'   markers. \emph{Crop Science, 52}, 707-719.
#' @export
#' @examples
#' d <- expand.grid(gen = paste0("G", 1:10), env = paste0("E", 1:3))
#' p <- cv_partition(d, "gen", "env", scheme = "CV2", folds = 5, seed = 1)
#' p
cv_partition <- function(data, gen, env, scheme = c("CV1", "CV2", "CV0", "CV00", "random"),
                         folds = 5, seed = NULL, max_folds = NULL) {
  scheme <- match.arg(scheme)
  if (!is.null(seed)) set.seed(seed)
  cb <- unique(data.frame(gen = as.character(data[[gen]]), env = as.character(data[[env]]),
                          stringsAsFactors = FALSE))
  cb$key <- paste(cb$gen, cb$env, sep = "\r")
  gens <- unique(cb$gen); envs <- unique(cb$env)
  fl <- list()
  if (scheme == "CV1") {
    gf <- sample(rep_len(seq_len(folds), length(gens))); names(gf) <- gens
    for (f in seq_len(folds)) {
      te <- cb$key[gf[cb$gen] == f]
      fl[[f]] <- list(id = paste0("F", f), test = te, train = setdiff(cb$key, te))
    }
  } else if (scheme == "CV2") {
    fold_of <- integer(nrow(cb))
    for (g in gens) {
      ix <- which(cb$gen == g)
      ix <- ix[sample.int(length(ix))]
      off <- sample.int(folds, 1)
      fold_of[ix] <- ((off + seq_along(ix) - 2) %% folds) + 1
    }
    for (f in seq_len(folds)) {
      te <- cb$key[fold_of == f]
      fl[[f]] <- list(id = paste0("F", f), test = te, train = setdiff(cb$key, te))
    }
  } else if (scheme == "CV0") {
    for (e in envs) {
      te <- cb$key[cb$env == e]
      fl[[e]] <- list(id = e, test = te, train = setdiff(cb$key, te))
    }
  } else if (scheme == "CV00") {
    gf <- sample(rep_len(seq_len(folds), length(gens))); names(gf) <- gens
    for (e in envs) for (f in seq_len(folds)) {
      te <- cb$key[cb$env == e & gf[cb$gen] == f]
      tr <- cb$key[cb$env != e & gf[cb$gen] != f]
      fl[[paste(e, f, sep = "_F")]] <- list(id = paste(e, f, sep = "_F"), test = te, train = tr)
    }
  } else {
    ff <- sample(rep_len(seq_len(folds), nrow(cb)))
    for (f in seq_len(folds)) {
      te <- cb$key[ff == f]
      fl[[f]] <- list(id = paste0("F", f), test = te, train = setdiff(cb$key, te))
    }
  }
  if (!is.null(max_folds) && length(fl) > max_folds) fl <- fl[sort(sample(length(fl), max_folds))]
  out <- list(scheme = scheme, combos = cb, folds = fl, gen = gen, env = env)
  class(out) <- "gppartition"
  out
}

#' @export
print.gppartition <- function(x, ...) {
  nt <- vapply(x$folds, function(f) length(f$test), 1L)
  nr <- vapply(x$folds, function(f) length(f$train), 1L)
  cat("Cross-validation scheme", x$scheme, "with", length(x$folds), "folds over",
      nrow(x$combos), "genotype x environment combinations\n")
  cat(sprintf("  test size: %d-%d   training size: %d-%d\n", min(nt), max(nt), min(nr), max(nr)))
  invisible(x)
}

#' Cross-validation of one-stage and two-stage genomic prediction
#'
#' For every fold of a \code{\link{cv_partition}}, the model is fitted with
#' the training combinations and the genotype x environment combinations of
#' the test set are predicted. In the two-stage approach stage 1 is run once
#' on all plots and the BLUEs of the test combinations are masked; in the
#' one-stage approach the plots of the test combinations are removed. In both
#' cases predictive ability is the Pearson correlation, within environment,
#' between the predicted genetic values and the stage-1 BLUEs of the test
#' combinations (and, if \code{truth} is given, the true genetic values).
#'
#' @param data Plot-level data frame (or a data frame of means with
#'   \code{approach = "two-stage"} and \code{rep = NULL}).
#' @param y,gen,env,rep,block Column names.
#' @param ETA List of terms (see \code{\link{prepare_ETA}}).
#' @param partition A \code{"gppartition"} object.
#' @param approach \code{"two-stage"} or \code{"one-stage"}.
#' @param fixed Optional fixed formula (see \code{\link{one_stage}} and
#'   \code{\link{two_stage}}).
#' @param weighting Stage-2 weighting (two-stage only).
#' @param truth Optional column of \code{data} with the true genetic values.
#' @param verbose Print progress.
#' @param ... Kernel factorisation options passed to \code{\link{prepare_ETA}}
#'   (\code{method}, \code{tol}, \code{prop_var}).
#' @return An object of class \code{"gpcv"} with \code{predictions},
#'   \code{metrics} (by fold and environment), \code{summary} (by environment)
#'   and \code{time} (stage 1, kernel preparation, fitting and total).
#' @export
#' @examples
#' \donttest{
#' data(wheat599)
#' sim <- simulate_met(wheat599$X[1:80, ], n_env = 2, n_rep = 2, seed = 1)
#' G <- kernel_linear(wheat599$X[1:80, ])
#' part <- cv_partition(sim$data, "gen", "env", "CV1", folds = 4, seed = 1)
#' cv2 <- gp_cv(sim$data, "yield", "gen", "env", "rep", ETA = list(G = list(id = "gen", K = G)),
#'              partition = part, approach = "two-stage", truth = "tgv")
#' cv2$summary
#' }
gp_cv <- function(data, y, gen, env, rep = NULL, block = NULL, ETA, partition,
                  approach = c("two-stage", "one-stage"), fixed = NULL,
                  weighting = c("inverse_variance", "none"), truth = NULL,
                  verbose = TRUE, ...) {
  approach <- match.arg(approach)
  weighting <- match.arg(weighting)
  data <- as.data.frame(data)
  data$.key <- paste(data[[gen]], data[[env]], sep = "\r")
  s1 <- stage1(data, y, gen, env, rep, block, weighting = weighting)
  bl <- s1$blues
  bl$.key <- paste(bl[[gen]], bl[[env]], sep = "\r")
  if (!is.null(truth)) {
    tv <- tapply(data[[truth]], data$.key, mean)
    bl$.truth <- unname(tv[bl$.key])
  }
  fitdata <- if (approach == "two-stage") bl else data
  tp <- proc.time()[["elapsed"]]
  pETA <- prepare_ETA(ETA, fitdata, ...)
  t_prep <- proc.time()[["elapsed"]] - tp
  form <- if (!is.null(fixed)) stats::as.formula(fixed) else
    .default_fixed(y, env, if (approach == "one-stage") rep else NULL,
                   if (approach == "one-stage") block else NULL,
                   if (approach == "one-stage") 1 else 2)
  preds <- list(); ftimes <- numeric(0)
  for (i in seq_along(partition$folds)) {
    fo <- partition$folds[[i]]
    tr <- fitdata[fitdata$.key %in% fo$train, , drop = FALSE]
    w <- if (approach == "two-stage") tr$w else NULL
    fit <- gp_fit(form, tr, ETA = pETA, weights = w)
    ftimes[i] <- fit$time
    te <- bl[bl$.key %in% fo$test, , drop = FALSE]
    pg <- predict.gpfit(fit, te, type = "genetic")
    used <- !is.na(tr[[y]])
    if (!is.null(w)) used <- used & !is.na(w)
    em <- tapply(fit$fixed_fitted, as.character(tr[[env]])[used], mean)
    pr <- data.frame(fold = fo$id, gen = te[[gen]], env = te[[env]],
                     observed = te[[y]], predicted = pg,
                     response = pg + unname(em[as.character(te[[env]])]),
                     stringsAsFactors = FALSE)
    if (!is.null(truth)) pr$truth <- te$.truth
    preds[[i]] <- pr
    if (verbose) message(sprintf("[%s %s] fold %s (%d/%d): %.1f s", approach, partition$scheme,
                                 fo$id, i, length(partition$folds), fit$time))
  }
  P <- do.call(rbind, preds); rownames(P) <- NULL
  grp <- split(P, list(P$fold, P$env), drop = TRUE)
  M <- do.call(rbind, lapply(grp, function(d) {
    data.frame(fold = d$fold[1], env = d$env[1], n = nrow(d),
               cor = if (nrow(d) > 2) stats::cor(d$observed, d$predicted) else NA_real_,
               cor_truth = if (!is.null(d$truth) && nrow(d) > 2) stats::cor(d$truth, d$predicted) else NA_real_,
               MSE = mean((d$observed - d$response)^2),
               stringsAsFactors = FALSE)
  }))
  rownames(M) <- NULL
  S <- do.call(rbind, lapply(split(M, M$env), function(d) {
    data.frame(env = d$env[1], folds = nrow(d), cor = mean(d$cor, na.rm = TRUE),
               cor_se = stats::sd(d$cor, na.rm = TRUE) / sqrt(sum(!is.na(d$cor))),
               cor_truth = mean(d$cor_truth, na.rm = TRUE),
               MSE = mean(d$MSE, na.rm = TRUE), stringsAsFactors = FALSE)
  }))
  rownames(S) <- NULL
  t1 <- if (approach == "two-stage") s1$time else 0
  tm <- c(stage1 = t1, prepare = t_prep, fitting = sum(ftimes), total = t1 + t_prep + sum(ftimes))
  out <- list(approach = approach, scheme = partition$scheme, predictions = P,
              metrics = M, summary = S, time = tm, fold_times = ftimes,
              call = match.call())
  class(out) <- "gpcv"
  out
}

#' @export
print.gpcv <- function(x, ...) {
  cat(sprintf("Cross-validation %s, %s approach, %d folds\n", x$scheme, x$approach,
              length(x$fold_times)))
  print(x$summary, digits = 3, row.names = FALSE)
  cat(sprintf("Time (s): stage1 = %.1f, prepare = %.1f, fitting = %.1f, total = %.1f\n",
              x$time[1], x$time[2], x$time[3], x$time[4]))
  invisible(x)
}

#' @export
summary.gpcv <- function(object, ...) object$summary

#' Plot cross-validation results
#'
#' Box plots of the within-environment predictive correlations across folds.
#'
#' @param x A \code{"gpcv"} object.
#' @param metric \code{"cor"}, \code{"cor_truth"} or \code{"MSE"}.
#' @param ... Graphical parameters passed to \code{boxplot}.
#' @return Invisibly, \code{x}.
#' @export
plot.gpcv <- function(x, metric = c("cor", "cor_truth", "MSE"), ...) {
  metric <- match.arg(metric)
  graphics::boxplot(stats::as.formula(paste(metric, "~ env")), data = x$metrics,
                    main = paste(x$scheme, "-", x$approach), ylab = metric,
                    xlab = "Environment", col = "grey85", ...)
  invisible(x)
}

#' Compare cross-validation results of several approaches or models
#'
#' @param ... Named \code{"gpcv"} objects.
#' @return A data frame with one row per object and environment.
#' @export
compare_cv <- function(...) {
  L <- list(...)
  if (is.null(names(L))) names(L) <- paste0("M", seq_along(L))
  do.call(rbind, lapply(names(L), function(n) {
    s <- L[[n]]$summary
    data.frame(model = n, approach = L[[n]]$approach, scheme = L[[n]]$scheme, s,
               time_total = unname(L[[n]]$time["total"]), stringsAsFactors = FALSE)
  }))
}
