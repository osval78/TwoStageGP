#' Predict from a fitted genomic model
#'
#' @param object A \code{"gpfit"} object.
#' @param newdata Data frame with the \code{id} columns of the terms (and the
#'   fixed-effect variables if \code{type = "response"}). If missing, the
#'   training data are used.
#' @param type \code{"genetic"}: sum of the predicted kernel effects (e.g.
#'   \eqn{g_i + ge_{ij}}); \code{"response"}: genetic part plus the fixed
#'   effects evaluated with \code{newdata}.
#' @param terms Optional names of the \code{ETA} terms to add (default: all).
#' @param ... Not used.
#' @return Numeric vector of predictions.
#' @export
#' @examples
#' data(wheat599)
#' G <- kernel_linear(wheat599$X)
#' d <- data.frame(gen = rownames(wheat599$Y), y = wheat599$Y[, 1])
#' d$y[1:100] <- NA                         # 100 lines without phenotype
#' fit <- gp_fit(y ~ 1, d, ETA = list(G = list(id = "gen", K = G)))
#' p <- predict(fit, d[1:100, ])
#' cor(p, wheat599$Y[1:100, 1])
predict.gpfit <- function(object, newdata, type = c("genetic", "response"),
                          terms = NULL, ...) {
  type <- match.arg(type)
  if (missing(newdata) || is.null(newdata)) newdata <- object$data
  newdata <- as.data.frame(newdata)
  tn <- if (is.null(terms)) names(object$random) else terms
  pred <- numeric(nrow(newdata))
  for (t in tn) {
    info <- object$terms_info[[t]]
    if (!all(info$id %in% names(newdata))) stop("newdata lacks column(s) ", paste(info$id, collapse = ", "))
    u <- object$random[[t]][.make_key(newdata, info$id)]
    if (info$model == "IID") u[is.na(u)] <- 0
    pred <- pred + unname(u)
  }
  if (type == "response") {
    fx <- tryCatch({
      mf <- stats::model.frame(object$fixed_terms, newdata, xlev = object$xlevels, na.action = stats::na.pass)
      X <- stats::model.matrix(object$fixed_terms, mf)
      as.vector(X[, names(object$fixed), drop = FALSE] %*% object$fixed)
    }, error = function(e) {
      warning("Fixed part could not be evaluated for newdata (", conditionMessage(e),
              "); returning NA.")
      rep(NA_real_, nrow(newdata))
    })
    pred <- pred + fx
  }
  pred
}

#' @export
fitted.gpfit <- function(object, ...) object$fitted

#' @export
residuals.gpfit <- function(object, ...) object$residuals

#' @export
coef.gpfit <- function(object, ...) object$fixed

#' Variance components of a fitted model
#'
#' @param object A \code{"gpfit"} object.
#' @return Data frame with variance components and their proportions.
#' @export
varcomp <- function(object) object$varcomp

#' Predicted random effects of a term
#'
#' @param object A \code{"gpfit"} object.
#' @param term Name of the \code{ETA} term (default: the first one).
#' @return Named numeric vector with the predicted effects for all levels of
#'   the kernel (including levels without records).
#' @export
gp_effects <- function(object, term = NULL) {
  if (is.null(term)) term <- names(object$random)[1]
  object$random[[term]]
}

#' @export
print.gpfit <- function(x, ...) {
  ap <- if (is.null(x$approach)) "single fit" else x$approach
  cat("Genomic prediction model fitted with lme4 (", ap, ", ",
      if (x$REML) "REML" else "ML", ")\n", sep = "")
  cat("Formula:", deparse(x$formula), "\n")
  cat("Kernel terms: ", paste(vapply(x$terms_info, function(t)
    sprintf("%s[%s, %s]", t$name, paste(t$id, collapse = ":"), t$model), ""), collapse = "  "), "\n", sep = "")
  cat(sprintf("Records: %d   logLik: %.3f   AIC: %.2f   time: %.2f s\n", x$nobs, x$logLik, x$AIC,
              if (is.null(x$time_total)) x$time else x$time_total))
  cat("\nVariance components:\n")
  print(x$varcomp, digits = 4, row.names = FALSE)
  if (!isTRUE(x$converged)) cat("\nConvergence messages:", x$messages, "\n")
  invisible(x)
}

#' @export
summary.gpfit <- function(object, ...) {
  out <- list(varcomp = object$varcomp, fixed = object$fixed,
              fit = c(nobs = object$nobs, logLik = object$logLik, AIC = object$AIC, BIC = object$BIC),
              time = c(total = if (is.null(object$time_total)) object$time else object$time_total,
                       stage1 = if (is.null(object$time_stage1)) NA else object$time_stage1),
              approach = object$approach)
  class(out) <- "summary.gpfit"
  out
}

#' @export
print.summary.gpfit <- function(x, ...) {
  cat("Approach:", if (is.null(x$approach)) "single fit" else x$approach, "\n\nFixed effects:\n")
  print(round(x$fixed, 4))
  cat("\nVariance components:\n"); print(x$varcomp, digits = 4, row.names = FALSE)
  cat("\nFit statistics:\n"); print(round(x$fit, 3))
  cat("\nComputing time (s):\n"); print(round(x$time, 3))
  invisible(x)
}

#' Plot a fitted genomic model
#'
#' Scatter plot of observed versus fitted values, or the distribution of the
#' predicted effects of a term.
#'
#' @param x A \code{"gpfit"} object.
#' @param which \code{"fitted"} or \code{"effects"}.
#' @param term Term used when \code{which = "effects"}.
#' @param ... Graphical parameters.
#' @return Invisibly, \code{x}.
#' @export
plot.gpfit <- function(x, which = c("fitted", "effects"), term = NULL, ...) {
  which <- match.arg(which)
  if (which == "fitted") {
    graphics::plot(x$fitted, x$y, xlab = "Fitted", ylab = "Observed",
                   pch = 19, col = grDevices::adjustcolor("steelblue", 0.5), ...)
    graphics::abline(0, 1, lty = 2)
  } else {
    u <- gp_effects(x, term)
    graphics::hist(u, breaks = 30, main = paste("Predicted effects:", if (is.null(term)) names(x$random)[1] else term),
                   xlab = "Effect", col = "grey80", ...)
  }
  invisible(x)
}

#' Compare a one-stage and a two-stage fit
#'
#' @param one A \code{"gpfit"} object from \code{\link{one_stage}}.
#' @param two A \code{"gpfit"} object from \code{\link{two_stage}}.
#' @param newdata Optional genotype x environment combinations to predict;
#'   defaults to the stage-1 BLUE table of \code{two}.
#' @return A list with the correlation and maximum absolute difference of the
#'   predicted genetic values, both prediction vectors, the variance
#'   components side by side and the computing times.
#' @export
compare_stages <- function(one, two, newdata = NULL) {
  if (is.null(newdata)) newdata <- two$stage1$blues
  p1 <- predict.gpfit(one, newdata); p2 <- predict.gpfit(two, newdata)
  vc <- merge(one$varcomp[, 1:2], two$varcomp[, 1:2], by = "component", all = TRUE,
              suffixes = c("_one_stage", "_two_stage"), sort = FALSE)
  list(cor = stats::cor(p1, p2), max_abs_diff = max(abs(p1 - p2)),
       predictions = data.frame(newdata[, intersect(c(two$gen, two$env), names(newdata)), drop = FALSE],
                                one_stage = p1, two_stage = p2),
       varcomp = vc,
       time = c(one_stage = one$time_total, two_stage = two$time_total,
                ratio = one$time_total / two$time_total))
}
