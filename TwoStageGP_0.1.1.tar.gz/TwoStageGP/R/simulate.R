#' Simulate plot-level multi-environment trial data from marker genotypes
#'
#' Simulates the model
#' \deqn{y_{ijkl} = \mu + E_j + r_{jk} + b_{jkl} + g_i + (ge)_{ij} + e_{ijkl},}
#' with \eqn{g \sim N(0, \sigma^2_g G)}, \eqn{ge \sim N(0, \sigma^2_{ge}\, G
#' \otimes \Omega)}, where \eqn{G} is the linear genomic kernel of \code{X} and
#' \eqn{\Omega} is either the identity (\code{ge = "GxI"}) or the linear kernel
#' of simulated environmental covariates (\code{ge = "GxW"}). Replicates are
#' complete blocks; if \code{n_block} is given, each replicate is split into
#' incomplete blocks (alpha-lattice-like randomisation).
#'
#' @param X Marker matrix (row names = genotype identifiers).
#' @param n_env Number of environments.
#' @param n_rep Number of replicates per environment.
#' @param n_block Optional number of incomplete blocks per replicate.
#' @param mu Overall mean.
#' @param var_E,var_g,var_ge,var_rep,var_block Variances of environments,
#'   genomic main effects, genotype-by-environment, replicates and blocks.
#' @param var_e Residual (plot) variance; a vector of length \code{n_env}
#'   gives heterogeneous error variances.
#' @param ge \code{"GxI"} or \code{"GxW"}.
#' @param n_cov Number of environmental covariates simulated.
#' @param seed Random seed.
#' @return A list with \code{data} (plot records with columns \code{gen},
#'   \code{env}, \code{rep}, optionally \code{block}, \code{yield} and the true
#'   genetic value \code{tgv}), \code{truth} (one row per genotype x
#'   environment), \code{W} (environmental covariates), \code{G} and
#'   \code{params}.
#' @export
#' @examples
#' data(wheat599)
#' sim <- simulate_met(wheat599$X[1:50, ], n_env = 3, n_rep = 2, seed = 2)
#' str(sim$data)
simulate_met <- function(X, n_env = 4, n_rep = 2, n_block = NULL, mu = 5,
                         var_E = 1, var_g = 0.30, var_ge = 0.20, var_e = 0.60,
                         var_rep = 0.05, var_block = 0.10,
                         ge = c("GxI", "GxW"), n_cov = 8, seed = NULL) {
  ge <- match.arg(ge)
  if (!is.null(seed)) set.seed(seed)
  if (is.null(rownames(X))) rownames(X) <- paste0("G", seq_len(nrow(X)))
  G <- kernel_linear(X)
  ng <- nrow(G); gens <- rownames(G)
  envs <- sprintf("E%d", seq_len(n_env))
  LG <- t(chol(G + diag(1e-6, ng)))
  W <- matrix(stats::rnorm(n_env * n_cov), n_env, n_cov,
              dimnames = list(envs, paste0("cov", seq_len(n_cov))))
  Om <- if (ge == "GxI") diag(n_env) else {
    O <- kernel_env(W); O <- O / mean(diag(O)); O + diag(0.05, n_env)
  }
  LO <- t(chol(Om))
  g <- sqrt(var_g) * as.vector(LG %*% stats::rnorm(ng))
  GEm <- sqrt(var_ge) * (LG %*% matrix(stats::rnorm(ng * n_env), ng, n_env) %*% t(LO))
  Eeff <- stats::rnorm(n_env, 0, sqrt(var_E))
  ve <- rep_len(var_e, n_env)
  truth <- data.frame(gen = rep(gens, times = n_env), env = rep(envs, each = ng),
                      g = rep(g, times = n_env), ge = as.vector(GEm),
                      stringsAsFactors = FALSE)
  truth$tgv <- truth$g + truth$ge
  recs <- list()
  for (j in seq_len(n_env)) for (k in seq_len(n_rep)) {
    ord <- sample(ng)
    d <- data.frame(gen = gens[ord], env = envs[j], rep = paste0("R", k),
                    stringsAsFactors = FALSE)
    rk <- stats::rnorm(1, 0, sqrt(var_rep))
    bl <- 0
    if (!is.null(n_block)) {
      d$block <- paste0("B", rep(seq_len(n_block), length.out = ng))
      bef <- stats::rnorm(n_block, 0, sqrt(var_block))
      bl <- bef[as.integer(sub("B", "", d$block))]
    }
    tg <- truth$tgv[match(paste(d$gen, d$env), paste(truth$gen, truth$env))]
    d$tgv <- tg
    d$yield <- mu + Eeff[j] + rk + bl + tg + stats::rnorm(ng, 0, sqrt(ve[j]))
    recs[[length(recs) + 1]] <- d
  }
  data <- do.call(rbind, recs); rownames(data) <- NULL
  list(data = data, truth = truth, W = W, G = G,
       params = list(mu = mu, var_E = var_E, var_g = var_g, var_ge = var_ge,
                     var_e = var_e, var_rep = var_rep, var_block = var_block,
                     ge = ge, n_env = n_env, n_rep = n_rep, n_block = n_block))
}
