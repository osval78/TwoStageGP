#' Wheat data set: 599 CIMMYT lines, 1279 DArT markers, 4 environments
#'
#' Grain yield of 599 historical wheat lines from the CIMMYT Global Wheat
#' Program evaluated in four mega-environments, genotyped with 1279 DArT
#' markers, together with the additive relationship matrix derived from the
#' pedigree. The phenotypes are genotype means (one value per line and
#' environment) standardised to mean zero and unit variance within each
#' environment, i.e. they are already stage-1 summaries. The data were
#' published by Crossa et al. (2010) and are distributed (GPL-3) with the
#' 'BGLR' package (Pérez & de los Campos, 2014) as \code{wheat}.
#'
#' @format A list with three elements:
#' \describe{
#'   \item{\code{X}}{Integer matrix 599 x 1279 of DArT markers coded 0/1;
#'     row names are the line identifiers.}
#'   \item{\code{Y}}{Numeric matrix 599 x 4 of standardised grain yield in
#'     environments \code{E1}-\code{E4} (original codes 1, 2, 4 and 5).}
#'   \item{\code{A}}{Numeric matrix 599 x 599, pedigree (coefficient of
#'     parentage) relationship matrix.}
#' }
#' @source Crossa, J., de los Campos, G., Pérez, P., Gianola, D., Burgueño,
#'   J., Araus, J. L., et al. (2010). Prediction of genetic values of
#'   quantitative traits in plant breeding using pedigree and molecular
#'   markers. \emph{Genetics, 186}, 713-724.
#' @references Pérez, P., & de los Campos, G. (2014). Genome-wide regression
#'   and prediction with the BGLR statistical package. \emph{Genetics, 198},
#'   483-495.
#' @examples
#' data(wheat599)
#' dim(wheat599$X); head(wheat599$Y)
"wheat599"
