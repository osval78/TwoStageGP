#' Clean a marker matrix
#'
#' Imputes missing values with the column mean and removes monomorphic
#' markers (zero variance). Used internally by all kernel functions.
#'
#' @param X Numeric matrix (individuals in rows, markers in columns).
#' @return A numeric matrix without missing values or monomorphic columns.
#' @export
#' @examples
#' X <- matrix(rbinom(50, 2, 0.4), 5, 10)
#' clean_markers(X)
clean_markers <- function(X) {
  X <- as.matrix(X)
  storage.mode(X) <- "double"
  if (anyNA(X)) {
    cm <- colMeans(X, na.rm = TRUE)
    w <- which(is.na(X), arr.ind = TRUE)
    X[w] <- cm[w[, 2]]
  }
  sdv <- apply(X, 2, stats::sd)
  keep <- is.finite(sdv) & sdv > 0
  X[, keep, drop = FALSE]
}

.set_names_K <- function(K, nms) {
  if (is.null(nms)) nms <- as.character(seq_len(nrow(K)))
  dimnames(K) <- list(nms, nms)
  K
}

#' Linear (genomic) relationship matrix: GBLUP kernel
#'
#' Computes the linear kernel \eqn{G = W W' / c}, where \eqn{W} is the
#' (standardised or centred) marker matrix. A GBLUP term with this kernel is
#' equivalent to ridge regression on the markers (RR-BLUP).
#'
#' @param X Marker matrix (lines in rows, markers in columns). Row names are
#'   used as the level names of the kernel and must match the genotype
#'   identifiers in the phenotypic data.
#' @param method \code{"standardize"} (default): columns centred and scaled,
#'   \eqn{c = p}. \code{"VanRaden"}: VanRaden (2008) method 1 for 0/1/2 coding,
#'   \eqn{c = 2 \sum p_j (1 - p_j)}. \code{"center"}: centred columns and
#'   \eqn{c} equal to the mean of the diagonal.
#' @return A symmetric \eqn{n \times n} matrix with dimnames.
#' @references VanRaden, P. M. (2008). Efficient methods to compute genomic
#'   predictions. \emph{Journal of Dairy Science, 91}, 4414-4423.
#' @export
#' @examples
#' data(wheat599)
#' G <- kernel_linear(wheat599$X)
#' mean(diag(G))
kernel_linear <- function(X, method = c("standardize", "VanRaden", "center")) {
  method <- match.arg(method)
  nms <- rownames(X)
  X <- clean_markers(X)
  if (method == "standardize") {
    W <- scale(X)
    G <- tcrossprod(W) / ncol(W)
  } else if (method == "VanRaden") {
    p <- colMeans(X) / 2
    W <- sweep(X, 2, 2 * p)
    G <- tcrossprod(W) / (2 * sum(p * (1 - p)))
  } else {
    W <- scale(X, scale = FALSE)
    G <- tcrossprod(W)
    G <- G / mean(diag(G))
  }
  G <- .set_names_K(G, nms)
  attr(G, "kernel") <- paste0("linear (", method, ")")
  G
}

#' Gaussian kernel for RKHS regression
#'
#' Computes \eqn{K_{ii'} = \exp(-h \, d^2_{ii'} / q)}, where \eqn{d_{ii'}} is
#' the Euclidean distance between the (standardised) marker profiles of lines
#' \eqn{i} and \eqn{i'} and \eqn{q} is the median of the squared distances
#' (Pérez-Elizalde et al., 2015). Several bandwidths can be supplied to build
#' a multi-kernel (kernel averaging) model as in de los Campos et al. (2010).
#'
#' @param X Marker matrix with genotype identifiers as row names.
#' @param h Bandwidth parameter(s). A vector returns a list of kernels.
#' @param scale Logical; standardise markers before computing distances.
#' @return A kernel matrix, or a list of kernel matrices if \code{length(h) > 1}.
#' @export
#' @examples
#' data(wheat599)
#' K <- kernel_gaussian(wheat599$X[1:50, ], h = 1)
#' range(K)
kernel_gaussian <- function(X, h = 1, scale = TRUE) {
  nms <- rownames(X)
  X <- clean_markers(X)
  if (scale) X <- scale(X)
  D2 <- as.matrix(stats::dist(X))^2
  q <- stats::median(D2[upper.tri(D2)])
  out <- lapply(h, function(hh) {
    K <- exp(-hh * D2 / q)
    K <- .set_names_K(K, nms)
    attr(K, "kernel") <- paste0("Gaussian (h = ", hh, ")")
    K
  })
  if (length(h) == 1) out[[1]] else stats::setNames(out, paste0("h", h))
}

#' Environmental relationship matrix
#'
#' Builds a covariance matrix among environments from environmental
#' covariates (e.g. temperature, rainfall, radiation by growth stage), as in
#' the reaction-norm model of Jarquín et al. (2014).
#'
#' @param W Matrix of environmental covariates (environments in rows).
#'   Row names must match the environment identifiers of the data.
#' @param type \code{"linear"} (\eqn{\Omega = W W'/q}) or \code{"gaussian"}.
#' @param h Bandwidth when \code{type = "gaussian"}.
#' @return A symmetric matrix with dimnames.
#' @export
#' @examples
#' W <- matrix(rnorm(40), 4, 10, dimnames = list(paste0("E", 1:4), NULL))
#' kernel_env(W)
kernel_env <- function(W, type = c("linear", "gaussian"), h = 1) {
  type <- match.arg(type)
  if (type == "linear") {
    nms <- rownames(W)
    Ws <- scale(clean_markers(W))
    O <- tcrossprod(Ws) / ncol(Ws)
    O <- .set_names_K(O, nms)
    attr(O, "kernel") <- "environmental (linear)"
    O
  } else {
    K <- kernel_gaussian(W, h = h)
    attr(K, "kernel") <- paste0("environmental (Gaussian, h = ", h, ")")
    K
  }
}

#' Identity kernel
#'
#' @param levels Character vector with the level names (e.g. environments).
#' @return An identity matrix with dimnames.
#' @export
#' @examples
#' kernel_identity(c("E1", "E2", "E3"))
kernel_identity <- function(levels) {
  levels <- as.character(levels)
  K <- diag(length(levels))
  K <- .set_names_K(K, levels)
  attr(K, "kernel") <- "identity"
  K
}

#' Kronecker product of two kernels with combined level names
#'
#' Returns \eqn{K_1 \otimes K_2} with level names \code{"a:b"}. This is the
#' covariance of an interaction term (e.g. genotype-by-environment). In
#' \code{\link{gp_fit}} it is usually more efficient to give the list
#' \code{K = list(K1, K2)} in the term instead of the explicit product.
#'
#' @param K1,K2 Kernel matrices with dimnames.
#' @param sep Separator used for the combined levels.
#' @return A matrix of dimension \code{nrow(K1)*nrow(K2)}.
#' @export
#' @examples
#' kernel_kron(kernel_identity(c("a", "b")), kernel_identity(c("E1", "E2")))
kernel_kron <- function(K1, K2, sep = ":") {
  l1 <- rownames(K1); l2 <- rownames(K2)
  K <- kronecker(K1, K2)
  nms <- paste(rep(l1, each = length(l2)), rep(l2, times = length(l1)), sep = sep)
  .set_names_K(as.matrix(K), nms)
}
