#' TwoStageGP: one-stage and two-stage genomic prediction with lme4
#'
#' The package fits genomic prediction models whose linear predictor is a sum
#' of terms, each with a user-supplied relationship matrix (as in 'BGLR'),
#' but estimates variance components by REML with 'lme4'. Main functions:
#' \itemize{
#'   \item kernels: \code{\link{kernel_linear}} (GBLUP), \code{\link{kernel_gaussian}}
#'     (RKHS), \code{\link{kernel_env}}, \code{\link{kernel_identity}},
#'     \code{\link{kernel_kron}};
#'   \item model fitting: \code{\link{gp_fit}}, \code{\link{one_stage}},
#'     \code{\link{stage1}}, \code{\link{two_stage}}, \code{\link{compare_stages}};
#'   \item cross-validation: \code{\link{cv_partition}} (CV1, CV2, CV0, CV00,
#'     random), \code{\link{gp_cv}}, \code{\link{compare_cv}};
#'   \item data: \code{\link{wheat599}}, \code{\link{simulate_met}}.
#' }
#' See \code{vignette("TwoStageGP")} for a complete tutorial.
#' @importFrom utils globalVariables
#' @keywords internal
"_PACKAGE"
