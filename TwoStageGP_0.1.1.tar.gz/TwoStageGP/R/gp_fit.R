#' Fit a genomic prediction mixed model with lme4 and user-supplied kernels
#'
#' Fits the linear mixed model
#' \deqn{y = X\beta + \sum_{k=1}^{K} Z_k u_k + \sum_{s} Z_s v_s + e,}
#' where \eqn{u_k \sim N(0, \sigma^2_k K_k)} are the terms in \code{ETA}
#' (each with its own relationship matrix), \eqn{v_s} are optional standard
#' \pkg{lme4} random effects written in \code{formula} (e.g. \code{(1|block)}),
#' and \eqn{e \sim N(0, \sigma^2_e W^{-1})} with \eqn{W} = diag(\code{weights}).
#'
#' Each kernel term is reparameterised as \eqn{u_k = L_k z_k} with
#' \eqn{K_k = L_k L_k'} and \eqn{z_k \sim N(0, \sigma^2_k I)}, the design matrix
#' \eqn{Z_k L_k} replaces the default \pkg{lme4} design through the modular
#' functions \code{lFormula}, \code{mkLmerDevfun}, \code{optimizeLmer} and
#' \code{mkMerMod}, and variance components are estimated by (RE)ML. When the
#' dimension of a term exceeds the number of records the model is still
#' estimable because the effects are penalised. Predictions are returned for
#' \emph{all} levels of the kernel, including genotypes without records, as
#' \eqn{\hat u_k = L_k E(z_k \mid y)}.
#'
#' @param formula Fixed-effects formula (response on the left), optionally
#'   including standard \pkg{lme4} random terms, e.g. \code{y ~ env} or
#'   \code{y ~ env + env:rep + (1|env:rep:block)}.
#' @param data Data frame.
#' @param ETA List of kernel / marker terms, see \code{\link{prepare_ETA}}.
#'   Can also be an already prepared \code{"gpETA"} object.
#' @param weights Optional vector of residual weights (e.g. inverse variances
#'   of BLUEs in a two-stage analysis).
#' @param REML Logical: REML (default) or ML.
#' @param method,tol,prop_var Kernel factorisation options (see \code{\link{factor_K}});
#'   ignored when \code{ETA} is already prepared.
#' @param optimizer Optimiser passed to \code{lme4::optimizeLmer}.
#' @param keep_lmer Keep the underlying \code{merMod} object (can be large).
#' @return An object of class \code{"gpfit"} with elements \code{fixed},
#'   \code{varcomp}, \code{random} (named vectors of predicted effects for all
#'   levels of each term), \code{fitted}, \code{residuals}, \code{logLik},
#'   \code{AIC}, \code{BIC}, \code{marker_effects} (for \code{"RR"} terms),
#'   \code{time} (seconds) and others.
#' @seealso \code{\link{one_stage}}, \code{\link{two_stage}}, \code{\link{gp_cv}}
#' @export
#' @examples
#' data(wheat599)
#' G <- kernel_linear(wheat599$X)
#' d <- data.frame(gen = rownames(wheat599$Y), y = wheat599$Y[, 1])
#' fit <- gp_fit(y ~ 1, d, ETA = list(G = list(id = "gen", K = G)))
#' fit
gp_fit <- function(formula, data, ETA = NULL, weights = NULL, REML = TRUE,
                   method = "chol", tol = 1e-8, prop_var = 1, optimizer = "nloptwrap", keep_lmer = FALSE) {
  t0 <- proc.time()[["elapsed"]]
  data <- as.data.frame(data)
  formula <- stats::as.formula(formula)
  yname <- all.vars(formula[[2]])
  if (length(yname) != 1) stop("The left-hand side of 'formula' must be a single response column.")
  ok <- !is.na(data[[yname]])
  if (!is.null(weights)) {
    if (length(weights) != nrow(data)) stop("'weights' must have one value per row of data.")
    ok <- ok & !is.na(weights)
  }
  data <- droplevels(data[ok, , drop = FALSE])
  if (!is.null(weights)) weights <- weights[ok]
  n <- nrow(data)
  has_bars <- !is.null(lme4::findbars(formula))
  if (is.null(ETA) && !has_bars) stop("Provide at least one random term (ETA or a (1|g) term).")
  pETA <- if (is.null(ETA)) list() else prepare_ETA(ETA, data, method = method, tol = tol, prop_var = prop_var)

  # ---- design for each kernel term: W_k = Z_k L_k (sparse, q_k columns)
  dnames <- character(0); Wl <- list()
  for (k in seq_along(pETA)) {
    tm <- pETA[[k]]
    idx <- match(.make_key(data, tm$id), tm$levels)
    if (anyNA(idx)) stop("Term '", tm$name, "': some records have levels not in the kernel.")
    dn <- paste0(".gp", k, "_", make.names(tm$name))
    Wl[[dn]] <- tm$L[idx, , drop = FALSE]
    data[[dn]] <- factor(rep_len(seq_len(min(n, ncol(tm$L))), n))
    dnames <- c(dnames, dn)
  }
  rhs <- c(deparse(formula[[3]], width.cutoff = 500L), sprintf("(1|%s)", dnames))
  form <- stats::as.formula(paste(yname, "~", paste(rhs, collapse = " + ")))
  ctrl <- lme4::lmerControl(check.nobs.vs.nlev = "ignore", check.nobs.vs.rankZ = "ignore",
                            check.nlev.gtr.1 = "ignore", check.nobs.vs.nRE = "ignore",
                            calc.derivs = FALSE)
  if (!is.null(weights)) {
    data$.gp_w <- weights
    lf <- lme4::lFormula(form, data = data, REML = REML, weights = .gp_w, control = ctrl)
  } else {
    lf <- lme4::lFormula(form, data = data, REML = REML, control = ctrl)
  }
  # ---- replace the Z blocks of the kernel terms and rebuild Lambda
  re <- lf$reTrms
  if (any(lengths(re$cnms) != 1))
    stop("Only random-intercept terms such as (1|block) are supported in 'formula'.")
  cn <- names(re$cnms); Gp <- re$Gp
  blocks <- vector("list", length(cn))
  for (i in seq_along(cn)) {
    if (cn[i] %in% dnames) {
      blocks[[i]] <- Matrix::t(Wl[[cn[i]]])
      re$Ztlist[[i]] <- blocks[[i]]
    } else blocks[[i]] <- re$Zt[(Gp[i] + 1):Gp[i + 1], , drop = FALSE]
  }
  nb <- vapply(blocks, nrow, 1L)
  Gp <- c(0L, cumsum(nb))
  re$Gp <- as.integer(Gp)
  re$Zt <- .as_dgC(do.call(rbind, blocks))
  re$Lambdat <- Matrix::sparseMatrix(i = seq_len(sum(nb)), j = seq_len(sum(nb)), x = 1)
  re$Lind <- rep(seq_along(cn), times = nb)
  lf$reTrms <- re
  devfun <- do.call(lme4::mkLmerDevfun, lf)
  opt <- lme4::optimizeLmer(devfun, optimizer = optimizer, calc.derivs = FALSE)
  fit <- lme4::mkMerMod(environment(devfun), opt, lf$reTrms, fr = lf$fr)

  # ---- extract results
  b <- as.vector(lme4::getME(fit, "b"))
  vc <- as.data.frame(lme4::VarCorr(fit))
  random <- list(); marker_effects <- list(); random_other <- list()
  comp <- character(0); varv <- numeric(0)
  for (i in seq_along(cn)) {
    bi <- b[(Gp[i] + 1):Gp[i + 1]]
    v_i <- vc$vcov[vc$grp == cn[i] & is.na(vc$var2)][1]
    if (cn[i] %in% dnames) {
      k <- match(cn[i], dnames); tm <- pETA[[k]]
      u <- as.vector(tm$L %*% bi); names(u) <- tm$levels
      random[[tm$name]] <- u
      if (tm$model == "RR") {
        # BLUP of marker effects: b = Xs' (Xs Xs')^- u
        Ginv <- MASS_ginv(tcrossprod(tm$Xs))
        marker_effects[[tm$name]] <- stats::setNames(as.vector(crossprod(tm$Xs, Ginv %*% u)),
                                                     tm$marker_names)
      }
      comp <- c(comp, tm$name)
    } else {
      random_other[[cn[i]]] <- bi
      comp <- c(comp, cn[i])
    }
    varv <- c(varv, v_i)
  }
  s2e <- stats::sigma(fit)^2
  varcomp <- data.frame(component = c(comp, "Residual"), variance = c(varv, s2e))
  varcomp$proportion <- varcomp$variance / sum(varcomp$variance)
  X <- lme4::getME(fit, "X")
  beta <- lme4::fixef(fit)
  ll <- stats::logLik(fit)
  keepvars <- unique(c(yname, all.vars(lme4::nobars(formula)[[3]]),
                       unlist(lapply(pETA, `[[`, "id"))))
  keepvars <- intersect(keepvars, names(data))
  out <- list(call = match.call(), formula = formula, response = yname,
              fixed = beta, varcomp = varcomp, random = random,
              random_other = random_other, marker_effects = marker_effects,
              fitted = stats::fitted(fit), residuals = stats::residuals(fit),
              fixed_fitted = as.vector(X %*% beta),
              y = data[[yname]], data = data[, keepvars, drop = FALSE],
              terms_info = lapply(pETA, function(t) t[c("name", "id", "model", "rank")]),
              fixed_terms = stats::delete.response(stats::terms(lme4::nobars(formula))),
              xlevels = stats::.getXlevels(stats::terms(lme4::nobars(formula)), lf$fr),
              logLik = as.numeric(ll), AIC = stats::AIC(fit), BIC = stats::BIC(fit),
              nobs = n, REML = REML, weights = weights,
              converged = is.null(fit@optinfo$conv$lme4$messages),
              messages = fit@optinfo$conv$lme4$messages,
              time = proc.time()[["elapsed"]] - t0,
              lmer = if (keep_lmer) fit else NULL)
  class(out) <- "gpfit"
  out
}

MASS_ginv <- function(A, tol = sqrt(.Machine$double.eps)) {
  s <- svd(A)
  pos <- s$d > max(tol * s$d[1L], 0)
  s$v[, pos, drop = FALSE] %*% ((1 / s$d[pos]) * t(s$u[, pos, drop = FALSE]))
}

utils::globalVariables(".gp_w")
